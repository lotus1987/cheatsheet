#!/usr/local/bin/perl

##############################################################################
#                                                                            #
# Copyright (C) Infineon Technologies (2021)                                 #
#                                                                            #
# All rights reserved.                                                       #
#                                                                            #
# This document contains proprietary information belonging to Infineon       #
# Technologies. Passing on and copying of this document, and communication   #
# of its contents is not permitted without prior written authorization.      #
#                                                                            #
##############################################################################
#                                                                            #
#  FILENAME  : MC-ISAR_TC3xx_FEE_data_analyzer.pl                            #
#                                                                            #
#  VERSION   : 1.0.0                                                         #
#                                                                            #
#  DATE      : 29-11-2021                                                    #
#                                                                            #
#  PLATFORM  : Infineon AURIX2G                                              #
#                                                                            #
#  AUTHOR    : DL-AUTOSAR-Engineering                                        #
#                                                                            #
#  VENDOR    : Infineon Technologies                                         #
#                                                                            #
#  DESCRIPTION  : Perl script to analyze FEE dflash data dump                #
#                                                                            #
#  MAY BE CHANGED BY USER : Yes                                              #
#                                                                            #
##############################################################################
#                     REVISION HISTORY                                       #
##############################################################################
##############################################################################
# REVISION NUMBER    : 1.0.0                                                 #
# CHANGE DESCRIPTION : Initial version                                       #
##############################################################################

use strict;
use Win32;
#Module for XML Processing and Parsing
use XML::LibXML;
use XML::LibXML::Iterator;    
#Module to handle with file operations       
use File::Spec::Functions 'catfile'; 
#Module for processing with Excel sheets.
use Spreadsheet::WriteExcel;
#Module to work with data structures
use List::Util qw(min);
select(STDERR);
$| = 1;
select(STDOUT); 
$| = 1;

#Required variables
my $copyhandle;
my ($addresscount,$addressrange, $bin, $bytelen,$bytelength, $choice,$col, $copy, $copy1, $count,  $crc, $dataflag,  $datapagecount, $erasedcount);
$addresscount=$addressrange= $bin= $bytelen=$bytelength= $choice=$col= $copy= $copy1= $count=  $crc= $dataflag=  $datapagecount= $erasedcount = 0;
my ($filehandle, $filehandle1, $filename, $flagset, $flagset1, $freespacebytes, $freespacepages, $immediate, $immediateblocksize, $immediatefreespacepages);
$filehandle, $filehandle1= $filename= $flagset= $flagset1= $freespacebytes= $freespacepages= $immediate= $immediateblocksize= $immediatefreespacepages;
my ($immediatefreespacebytes, $immediatelinecount, $immediatelinecount, $immediaterange, $in, $input, $input1, $linecount,$lineflag, $markercount);
$immediatefreespacebytes= $immediatelinecount= $immediatelinecount= $immediaterange= $in= $input= $input1= $linecount=$lineflag= $markercount = 0;
my ($maxblockcount,$memsize, $offset, $outputpath, $pagecount, $pagecount1, $printcount, $quasifeebytes, $quasifirstaddress, $r, $r1,$r3, $refcount, $rowlength );
$maxblockcount= $memsize= $offset= $outputpath= $pagecount= $pagecount1= $printcount= $quasifeebytes= $quasifirstaddress= $r= $r1= $r3= $refcount= $rowlength = 0;
my ($sector0freepages,$sector0freespace, $sector0immediatefreepages, $sector0immediatefreespace, $sector0missingimmediatespace,$sector0missingnormalspace );
$sector0freepages= $sector0freespace= $sector0immediatefreepages= $sector0immediatefreespace= $sector0missingimmediatespace =$sector0missingnormalspace = 0;
my ($sector0missingtotalspace, $sector0normalfreepages,$sector0normalfreespace,$sector1count, $sector1freepages,$sector1freespace,$sector1immediatefreepages);
$sector0missingtotalspace= $sector0normalfreepages= $sector0normalfreespace= $sector1count= $sector1freepages= $sector1freespace= $sector1immediatefreepages = 0;
my ($sector1immediatefreespace, $sector1missingimmediatespace,$sector1missingnormalspace, $sector1missingtotalspace, $sector1normalfreepages,$sector1normalfreespace);
$sector1immediatefreespace= $sector1missingimmediatespace= $sector1missingnormalspace= $sector1missingtotalspace= $sector1normalfreepages= $sector1normalfreespace = 0;
my ($sectorflag1,$sectorlines,$sectorsize,$sectorsize1,$set,$stateCounter,$stateflag);
$sectorflag1= $sectorlines= $sectorsize= $sectorsize1= $set= $stateCounter= $stateflag = 0;
my ($statepagecount,$threshold,$title,$totallinecount, $totallinecount1, $totallinecount2,$UnerasableWLCountdec,$validcount,$WL0,$WL1, $wordlinecount );
$statepagecount= $threshold= $title= $totallinecount= $totallinecount1= $totallinecount2= $UnerasableWLCountdec= $validcount= $WL0,$WL1= $wordlinecount  = 0;
my $baseaddress = 'AF00';
my $baseaddress1 = 'AF00';
my ($statepagebytes,$blocks);
$statepagebytes= $blocks = -1;
my ($sectorflag0,$sector0count);
$sectorflag0=$sector0count=1;
my ($input2, $copy2, $FlsTotalSize, $ConfigType);
$input2 = $copy2= $FlsTotalSize=$ConfigType=0;
our ($WLSum,$ByteCount,%EmptyWL,$WLAddress);
$WLSum= $ByteCount= $WLAddress = 0;
my ($PrevEmpty, $CurEmpty, $LongEmpty, $PrevAddr, $CurThreshold);
$PrevEmpty = $CurEmpty = $LongEmpty = $PrevAddr = $CurThreshold = 0;
my @WLIssues = ();
my (@blocks, @missingblock);
my (%blockaddress, %blocksize, %blockwritecycle,  %immediate_normal, %matchingblocks, %qsblockaddress, %qsblockinstance, %qsstaticmanager);
my (@FlsNumberOfSectors, @FlsSectorSize, @FlsSectorStartaddress);

use constant {
    DS => 0,
    QS => 1,
    DS_QS => 2,
};

# Standard device dflash0 sizes
# Note: For Dflash1 it is fixed 128KB for all devices
# Note: For some MO devices, the size may be less than the standard size shown below
my %DeviceSize = (
  TC39x => (1024 * 1024), 
  TC3Ex => (1024 * 1024), 
  TC38x => (512 * 1024), 
  TC37x => (256 * 1024), 
  TC36x => (128 * 1024), 
  TC35x => (128 * 1024), 
  TC33x => (128 * 1024), 
  TC32x => (128 * 1024)
  );

# Assigning Argument vector to variables
#========================================
if ($#ARGV == -1)
{	
	print "\nNo Inputs are given for CLI. Please follow the instructions in tool user manual\n";	
	exit;		
}
my $choice = $ARGV[0];
if( $choice eq "-CustomSize" )
{
	$memsize = $ARGV[1];
	$input  = $ARGV[2];		
	$input1 = $ARGV[3];
  $input2 = $ARGV[4];
	$outputpath =  $ARGV[5];	
}
else
{
	$input  = $ARGV[0];			
	$input1 = $ARGV[1];
	$input2 = $ARGV[2];
  $outputpath = $ARGV[3];	
}

#To copy hex file name to excel sheet
$input =~ m/\\([^\\]+)\./;
my $excelname = $1."_FEE_Report.xls";

#Creating excel sheet 	
if( defined $outputpath )
{
	my $path = catfile($outputpath, $excelname);	
	$filename  = Spreadsheet::WriteExcel->new($path);	
    $filehandle = $filename->add_worksheet("FEE_DetailedReport");
	$filehandle->set_column('A:B', 0.42);
	$filehandle->set_column('C:C', 12);
	$filehandle->set_column('D:D', 16);
	$filehandle->set_column('E:E', 17.6);
	$filehandle->set_column('F:F', 17.6);
	$filehandle->set_column('G:G', 12);
	$filehandle->set_column('H:K', 22);
	$filehandle->set_column('L:M', 26);
	$filehandle1 = $filename->add_worksheet('FEE_BlockReport.xls');
	$filehandle1->set_column('A:B', 0.3);
	$filehandle1->set_column('C:D', 28);
	$filehandle1->set_column('E:F', 17);
	$filehandle1->set_column('G:G', 19);
	$filehandle1->set_column('H:H', 18);
	$filehandle1->set_column('I:I', 13);
	$filehandle1->set_column('J:J', 35);
	$filehandle1->set_column('K:K', 21);
	$filehandle1->set_column('L:L', 25);
}
else
{
	$filename  = Spreadsheet::WriteExcel->new($excelname);
	$filehandle = $filename->add_worksheet("FEE_AnalyzerDetailed");
	$filehandle->set_column('A:B', 0.42);
	$filehandle->set_column('C:C', 12);
	$filehandle->set_column('D:D', 16);
	$filehandle->set_column('E:E', 17.6);
	$filehandle->set_column('F:F', 18);
	$filehandle->set_column('G:G', 12);
	$filehandle->set_column('H:K', 23);
	$filehandle->set_column('L:M', 26);	
	$filehandle1 = $filename->add_worksheet("Blocks");
	$filehandle1->set_column('A:B', 0.3);
	$filehandle1->set_column('C:D', 28);
	$filehandle1->set_column('E:F', 17);
	$filehandle1->set_column('G:G', 19);
	$filehandle1->set_column('H:H', 18);
	$filehandle1->set_column('I:I', 13);
	$filehandle1->set_column('J:J', 35);
	$filehandle1->set_column('K:K', 21);
	$filehandle1->set_column('L:L', 27);
}

#Formats for different cells
my %font    = (
                    font  => 'Arial',
                    size  => 16,
                    color => 'Black',
                    bold  => 1,					
                    align => 'center'
              );
my %font1   = (
                    font  => 'Arial',
                    size  => 12,
                    color => 'Black',
                    bold  => 1,
                    bg_color => 'silver',
                    align => 'center'
              );
my %font2   = (
                    font  => 'Arial',
                    size  => 14,
                    color => 'Green',
                    bold  => 1,					
              );
my %font3   = (
                    font  => 'Arial',
                    size  => 12,
                    color => 'red',
                    align => 'center'       					
              );
my %font4   = (
                    font  => 'Arial',
                    size  => 12,
                    color => 'black',
                    align => 'center'                   					
              );				  
my %font5   = (
                    font  => 'Arial',
                    size  => 12,
                    color => 'black',
                    align => 'Left'                   					
              );
my %font6   = (
                    font  => 'Arial',
                    size  => 12,
                    color => 'black',
                    align => 'center',
                    bold  => 1,					
              );	
my %font7   = (
                    font  => 'Arial',
                    size  => 12,
                    color => 'red',
                    align => 'left' 					
				      );	
my %font8   = (
                    font  => 'Arial',
                    size  => 12,
                    color => 'Black',
                    bold  => 1,					
                    align => 'left'
              );
              
my $format = $filename->add_format(%font);
my $format1 = $filename->add_format(%font1);
my $format2 = $filename->add_format(%font2);
my $format3 = $filename->add_format(%font3);
my $format4 = $filename->add_format(%font4);
my $format5 = $filename->add_format(%font5);
my $format6 = $filename->add_format(%font6);
my $format7 = $filename->add_format(%font7);
my $format8 = $filename->add_format(%font1);
my $format9 = $filename->add_format(%font2);
my $format10 = $filename->add_format(%font5);
my $format11 = $filename->add_format(%font6);
my $format12 = $filename->add_format(%font5);
my $format13 = $filename->add_format(%font4);
my $format14 = $filename->add_format(%font8);

$format1 ->set_text_wrap();
$format12 ->set_text_wrap();
$format12 ->set_indent();
$format13 ->set_text_wrap();

$filehandle->write(++$r, 5, "MC-ISAR TC3xx FEE ANALYZER  - Version 1.0 - Detailed", $format);
$filehandle->write(++$r, 4, "--This result sheet is to be used for demo purpose only--");
$filehandle1->write(++$r1, 5, "MC-ISAR TC3xx FEE ANALYZER  - Version 1.0 - FEE Blocks", $format);
$filehandle1->write(++$r1, 4, "--This result sheet is to be used for demo purpose only--");

print "\n\n MC-ISAR TC3xx FEE Analyzer Tool - Version 1.0\n"; 
print " =============================================\n";
print " ----------- For demo purpose only -----------\n ";
print "\n (Retrival of double sector and quasi block information from Dflash dump)\n";
print "\n MC-ISAR TC3xx FEE dump analysis started....\n\n";
#calling subroutines
enterinputfiles();
selectdevice();

#Working with copy.hex to retrieve information from it.
open($copyhandle, '<', $copy) or die "\nCan't open $copy: $!\n";
$copy =~ s/\n+/\n/g;
#-----------------------------------------------------------------------------------------------------------------------------------#
      
#Finding sector State Block information from datadump.
while( my $row = <$copyhandle>)
{  
	my @bytearray; #To store the a hex line
	my @dataarray; # To store the hex data without any header and trailer information
	# To remove spaces in a line.
	$row =~ s/^\s+|\s+$//g;		
	my $rowlength = length($row);		
	my ($byteref, $dataref) = pushdata($row, $rowlength); 	
	#Reference to arrays
	@bytearray = @$byteref; 
	@dataarray = @$dataref;
  if( $bytearray[3] == 00 || $bytearray[3] eq "00" || $bytearray[3] == 01 || $bytearray[3] eq "01" )
	{
		#Number of bytes in a line.		
		my $hexbytelength = $bytearray[0];	
		$bytelength = sprintf("%d", hex($hexbytelength));	
		#$bytelength1 = $bytelength;
		my $missingimmediatespace = 0;
		my $missingtotalspace = 0;
		my $missingnormalspace = 0; 				

    # Check if the WL is empty - start
    for (my $i = 0; $i < $bytelength, $WLSum != 0; $i++ )
    {				
      $WLSum |= $dataarray[$i];
    }      
    $ByteCount += $bytelength;
    
    if($ByteCount == 512)
    {
      $EmptyWL{$WLAddress} = $WLSum;
      $ByteCount = 0;
      $WLSum = 0;
      $WLAddress += 512;
    }
    # Check if the WL is empty - end
    
    if( $bytearray[3] == 01 && $count < $refcount  )
		{			
			my $var = sprintf("%0.4X", $offset);
			my $var1 = sprintf("%d", hex($var));				
			my $missinglines = ((65504 - $var1) / $bytelen);
			if( $printcount == 0 )
			{			
				$filehandle->write(++$r, 5,  "Addresses after 0x$baseaddress$var are missing in .hex file.", $format3);				
			}
			else
			{
				$filehandle->write(++$r, 5, "Addresses after 0x$baseaddress$var are missing in .hex file.",  $format3);								
			}			
			if( $missinglines > $immediatelinecount - 1 )
			{
				$immediatefreespacebytes = 0;
				$missingnormalspace = ( $missinglines - $immediatelinecount - 1 ) * $bytelen;
				$missingimmediatespace= $threshold;				
			}
			else
			{				
				$missingimmediatespace = ( $immediatelinecount - 1 - $missinglines) * $bytelen; 				
			}			
			$missingtotalspace = $missinglines * $bytelen;		
			$count = $refcount;
		}
    L: if( $count == $refcount && $sectorflag0 == 1)
		{		
			if( $printcount == 0 )
			{
				$filehandle -> write(++$r, 5, "No information is present in this sector.", $format3);	
			}	
			else
			{
				$printcount = 0;				
			}		
			$sector0freespace = $freespacebytes;
			$sector0freepages = $freespacepages;
			$sector0immediatefreespace = $immediatefreespacebytes;
			$sector0immediatefreepages = $immediatefreespacepages;
			$sector0normalfreespace = $freespacebytes - $immediatefreespacebytes;
			$sector0normalfreepages = $freespacepages - $immediatefreespacepages;
			$sector0missingtotalspace = $missingtotalspace;
			$sector0missingnormalspace = $missingnormalspace;
			$sector0missingimmediatespace = $missingimmediatespace;
			$freespacebytes = 0;
			$totallinecount1 = 0;
			$freespacepages = 0;			
			$immediatefreespacebytes = 0;
			$immediatefreespacepages = 0;	
			$sector0missingtotalspace = $missingtotalspace;
			$sector0missingnormalspace = $missingnormalspace;
			$sector0missingimmediatespace = $missingimmediatespace;
			$sectorflag0 = 0;
			$sectorflag1 = 1;
			$count = 0;       # Value increments when theline count reaches 2048.			
			$linecount = 0;	
			$totallinecount = 0;
			$lineflag = 1;
		}
		
		elsif( $count == $refcount && $sectorflag1 == 1)
		{			
			if( $printcount == 0 )
			{
				$filehandle -> write(++$r, 5, "No information is present in this sector.", $format3);	
			}	
			else
			{
				$printcount = 0;				
			}
			$sector1freespace = $freespacebytes;
			$sector1freepages = $freespacepages;			
			$sector1immediatefreespace = $immediatefreespacebytes;
			$sector1immediatefreepages = $immediatefreespacepages;
			$sector1missingtotalspace = $missingtotalspace;
			$sector1missingnormalspace = $missingnormalspace;
			$sector1missingimmediatespace = $missingimmediatespace;
			$sector1normalfreespace = $freespacebytes - $immediatefreespacebytes;
			$sector1normalfreepages = $freespacepages - $immediatefreespacepages;			
			$freespacebytes = 0;
			$freespacepages = 0;
			$totallinecount1 = 0;
			$immediatefreespacebytes = 0;
			$immediatefreespacepages = 0;	
			$sectorflag1 = 0;
			$sectorflag0 = 1;
			$count = 0;			
			$linecount = 0;	
			$totallinecount = 0;			
			$lineflag = 1;
			last;
		}
			
		if( $bytelength != 0 )
		{
			$bytelen = $bytelength;
			
			if( $count == 0 && $sectorflag0 == 1 && $sectorflag1 == 0 && $linecount == 0 && $bytelength > 0 )
			{			
				printsector("Sector0");
			}			
			if( $count == 0 && $sectorflag1 == 1 && $sectorflag0 == 0 && $linecount == 0 && $bytelength > 0 )
			{				
				printsector("Sector1");						
			}			
			for (my $i = 0; $i < $bytelength; $i = $i + 8 )
			{				
				if( $dataarray[$i] eq "59" )
				{
					$freespacebytes = $freespacebytes - 496;					
					$freespacepages = $freespacepages - 62;
				}	
				if( $dataarray[$i] eq "00" )
				{	
					$freespacebytes += 8;
					$freespacepages += 1;						
				}
			}

			$totallinecount1 += 1;
			#Finding immediate free space from data dump				
			$immediatelinecount = int ( $threshold / $bytelength ) + 1;
			$immediaterange = ( $sectorsize / $bytelength)  - $immediatelinecount;
			#Finding sector State Block information 	
			if( $sectorflag0 == 1 || $sectorflag1 == 1  )
			{			
				findsectorinfo(\@bytearray, \@dataarray);				
			}
		}		
	}	
	else
	{
		if( $bytearray[3] != 02 )
		{
			$baseaddress = $bytearray[4].$bytearray[5];
		}
    next; # if its a info line, repeat the procedure for the following line.
	}
}
close $copyhandle;

# Dummy data for testing with 475136 sector size and 200 threshold
# %EmptyWL = (
  # 475136 => 1,
  # 947712 => 0,
  # 948224 => 0,
  # 948736 => 1,
  # 949248 => 0,
  # 949760 => 1,
# );

if (($ConfigType == DS) or ($ConfigType == DS_QS))
{
  $CurThreshold = $FlsSectorSize[DS] - $threshold;
  foreach $WLAddress (sort {$a <=> $b} keys(%EmptyWL))
  {
    # Check if the WL is in sector0
    if (($WLAddress >= ($FlsSectorStartaddress[DS])) &&
        ($WLAddress < ($FlsSectorStartaddress[DS] + $FlsSectorSize[DS]))
       )
    {
      CheckWLIssue(); # Check for missing WLs     
    }
    elsif (($WLAddress >= ($FlsSectorStartaddress[DS] + $FlsSectorSize[DS])) &&
        ($WLAddress < ($FlsSectorStartaddress[DS] + (2 * $FlsSectorSize[DS])))
       )
    {
      if ($WLAddress == ($FlsSectorStartaddress[DS] + $FlsSectorSize[DS]))
      {
        $CurThreshold += $FlsSectorSize[DS]; # update threshold if sector crossed
        $PrevEmpty = 0;
        $CurEmpty = 0;
        $LongEmpty = 0;
        $PrevAddr = 0;
      }
      CheckWLIssue(); # Check for missing WLs
    }
    else
    {
      last;
    }
  }
}

#Finding Sector data blocks information
$addresscount = 0;
$baseaddress = 'AF00';
$baseaddress1 = 'AF00';
$bin = 0;
$count = 0;
$flagset = 0;
$flagset1 = 0;
$linecount = 0;
$offset = 0;
$pagecount = -1;
$printcount = 0; 
$sectorflag0 = 1;
$sectorflag1 = 0;
$stateflag = 0;
my ($blockcyclecounter, $blocknumber, $diff, $flag, $iterate);
$blockcyclecounter = $blocknumber = $diff = $flag = $iterate = 0;
my (%address, %bcc, %consistent, %differ, %firstbcc, %inconsistent, %lastbcc, %markermissing, %pagevalid, %pc);

# To extract the data information.
open($copyhandle, '<', $copy) or die "\nCan't open $copy: $!\n";

$r = $r + 2;  
$filehandle->write($r, 5, "Data Blocks Information for $title", $format);
$filehandle1->write($r1, 5, "FEE Blocks Information for $title", $format);

while( my $row = <$copyhandle>)
{  
	my @bytearray;
	my @dataarray; 	
	# To remove spaces in a line.
	$row =~ s/^\s+|\s+$//g;		
	my $rowlength = length($row);	
	my ($byteref,$dataref) = pushdata($row, $rowlength);	
	@bytearray = @$byteref;
	@dataarray = @$dataref;    
	if($bytearray[3] == 00 || $bytearray[3] eq "00" || $bytearray[3] == 01 || $bytearray[3] eq "01"  )
	{
		#Number of bytes in a line.		
		my $hexbytelength = $bytearray[0];	
		$bytelength = sprintf("%d", hex($hexbytelength));  		
		if( $bytearray[3] == 01 && $count < $refcount)
		{
			my $var = sprintf("%0.4X", $offset);
			if( $printcount == 0 )
			{				
				$filehandle->write(++$r, 5, "No Information is avaialble in this sector.", $format3);
				$filehandle->write(++$r, 5,  "Addresses after 0x$baseaddress$var are missing in .hex file.", $format3);
				$filehandle1->write(++$r1, 5, "No Information is avaialble in this sector.", $format3);
				$filehandle1->write(++$r1, 5,  "Addresses after 0x$baseaddress$var are missing in .hex file.", $format3);
			}
			else
			{
				printdatainfo();
				$filehandle->write(++$r, 5, "Addresses after 0x$baseaddress$var are missing in .hex file.", $format3);			
				$filehandle1->write(++$r1, 5, "Addresses after 0x$baseaddress$var are missing in .hex file.", $format3);		
			}
		}		
		#Printing the 2G FEE Block sheet in excel
		L11: if( $count == $refcount && $sectorflag0 == 1)
		{				
			$printcount = printcount($printcount);			
			$sectorflag0 = 0;
			$sectorflag1 = 1;
			$count = 0;			
			$linecount = 0;
			printdatainfo();	
		}		
		elsif( $count == $refcount && $sectorflag1 == 1)
		{			
			$printcount = printcount($printcount);		
			$sectorflag1 = 0;
			$sectorflag0 = 1;
			$count = 0;			
			$linecount = 0;	
			printdatainfo();
			last;
		}		
		if( $bytelength != 0  )
		{		
			if( $count == 0 && $sectorflag0 == 1 && $linecount == 0)
			{
				printdatatitle("Sector0");			
			}			
			if( $count == 0 && $sectorflag1 == 1 && $linecount == 0)
			{
				printdatatitle("Sector1");				
			}			
			if( $sectorflag0 == 1 || $sectorflag1 == 1  )
			{						
				finddatainfo(\@bytearray, \@dataarray);	
			}
		}
	}	
	else
	{
		if( $bytearray[3] != 02 )
		{
			$baseaddress = $bytearray[4].$bytearray[5];
		}
		next;
	}
}
close $copyhandle;

$r = $r + 2;  
$filehandle->write($r++, 5, "Skipped wordlines information for $title", $format);
if(@WLIssues > 0)
{
  foreach my $line (@WLIssues)
  {
    $filehandle->write($r++, 2, $line, $format5);	
  }
}
else
{
  $filehandle->write($r++, 2, "There are no skipped wordlines detected in the data dump", $format5);
}

#Findinf quasi block information
$r = $r + 1;  
$r1 = $r1 + 2;
$filehandle->write($r, 5, "Quasi static data blocks information for $title", $format);
$filehandle->write(++$r, 2, "Block", $format1);
$filehandle->write($r, 3, "Address", $format1);
$filehandle->write($r, 4, "BCC", $format1);
$filehandle->write($r, 5, "BCC - Complement", $format1);
$filehandle->write($r, 6, "BCC Validity", $format1);
$filehandle->write($r, 7, "Erase Completed", $format1);
$filehandle->write($r, 8, "Write Started", $format1);	
$filehandle->write($r, 9, "Write Completed", $format1);	
$filehandle->write($r, 10, "Erase Started", $format1);	
$filehandle->write($r, 11, "Status of Quasi", $format1);
$filehandle1->write($r1, 2, "Quasi static datablock (Quasi Static Algorithm)", $format2);		
$filehandle1 -> write(++$r1, 2, "Block", $format1);	
$filehandle1 -> write($r1, 3, "Address", $format1);
$filehandle1 -> write($r1, 4, "BCC", $format1);		
$filehandle1 -> write($r1, 5, "BCC - Complement", $format1);	
$filehandle1 -> write($r1, 6, "BCC Validity", $format1);	
$filehandle1->write($r1, 7, "Status", $format1);	
$filehandle1->write($r1, 8, "Block Instance", $format1);	
$filehandle1->write($r1, 9, "Block Size in .xdm(bytes)", $format1);	
$filehandle1->write($r1, 10, "Bytes in .hex", $format1);	

$blockcyclecounter = 0;
$linecount = 0;
$printcount = 0;
my ($bcccomplemet, $blockinstance, $blocknum, $fa, $quasiblockfreebytes, $quasicount, $quasilimit, $quasiflag,  $quasibytes, $quasioffset, $quasioffset1, $validblock);
$bcccomplemet= $blockinstance = $blocknum = $fa=  $quasiblockfreebytes=  $quasicount=  $quasilimit=$quasiflag= $quasibytes= $quasioffset=  $quasioffset1=  $validblock = 0;
my $offsetcount  = -1;
my %quasimissedbytes;
my %QSBCC;
my %qsinstances;

my (@quaisblock, @quasiarray);

# To extract the quasi data information.
open($copyhandle, '<', $copy) or die "\nCan't open $copy: $!\n";

while( my $row = <$copyhandle>)
{
	my @bytearray; 
	my @dataarray; 
	# To remove spaces in a line.
	$row =~ s/^\s+|\s+$//g;		
	my $rowlength = length($row);		
	my ($byteref, $dataref) = pushdata($row, $rowlength);	
	@bytearray = @$byteref; 
	@dataarray = @$dataref;	
	if( $bytearray[3] == 00 || $bytearray[3] eq "00" || $bytearray[3] == 01 || $bytearray[3] eq "01" )
	{
		if( $bytearray[3] == 01 || $bytearray[3] eq "01" )
		{
			if( $printcount == 0 )
			{
				$filehandle1->write(++$r1, 5, "No quasi information is present", $format3);
				$filehandle->write(++$r, 5, "No quasi information is present", $format3);
			}			
		}			
		my $hexbytelength = $bytearray[0];	
		$bytelength = sprintf("%d", hex($hexbytelength));		
		if( $bytelength != 0 )
		{
			if( $linecount <= 2048 / $bytelength )
			{
				my $address = $fa.$bytearray[1].$bytearray[2];				
				my $address1 = hex($address);				
				for (my $i = 0;$i < $bytelength; $i += 1 )
				{						
					foreach my $key (sort {$a <=> $b} keys %qsblockaddress)
					{						
						if( ($qsblockaddress{$key} == $address1) &&  ($qsstaticmanager{$key} eq "true") )
						{								
							if( $offsetcount != -1 && $quasilimit != 0 )
							{
								++$offsetcount;								
								$filehandle1->write($r1, 11, "$offsetcount", $format4);
								$quasimissedbytes{$blocknum} = $quasilimit - $offsetcount;
								$quasiblockfreebytes += $quasimissedbytes{$blocknum};
								$offsetcount = -1;
								$quasilimit = 0;								
							}							
							$quasiflag = 1;
							$blocknum = $key;
							$matchingblocks{$blocknum} =  "Present in FEE.xdm ";
							push(@missingblock, $blocknum);
							$quasilimit = $blocksize{$blocknum};							
						}					
					}			
					if($quasiflag == 1)
					{	
						$quasibytes += 1; 
						$offsetcount += 1;						
						push(@quasiarray, $dataarray[$i] );						
						if( $offsetcount == 35 )
						{						
							my $erasecomplete = join('', @quasiarray[2,3,0,1,6,7,5,4]);							
							my $writestarted = join('', @quasiarray[10,11,8,9,14,15,12,13]);
							my $writecomplete = join('', @quasiarray[18,19,16,17,22,23,20,21]);
							my $erasestarted  = join('', @quasiarray[26,27,24,25,30,31,28,29]);							
							$blockcyclecounter = join('', @quasiarray[32,33]);
							my $bc1 = hex($blockcyclecounter);
							$bcccomplemet = join('', @quasiarray[34,35]);																
							$filehandle->write(++$r, 2, $blocknum, $format4);
							$printcount += 1;							
							if( $immediate_normal{$blocknum} eq "true" )
							{								
									$filehandle1 -> write(++$r1, 2, "$blocknum (Immediate)", $format4);									
							}
							else
							{
								if ( $immediate_normal{$blocknum} eq "false" )
								{										
									$filehandle1 -> write(++$r1, 2, "$blocknum (Normal)", $format4);										
								}
							}																	
							my $addr = sprintf("%0.4X", $qsblockaddress{$blocknum});
							$filehandle->write($r, 3, "AF0$addr", $format4);					
							$filehandle1->write($r1, 3, "AF0$addr", $format4);					
							$filehandle->write($r, 4, "$blockcyclecounter, int - $bc1", $format4);
							$filehandle1->write($r1, 4, "$blockcyclecounter, int - $bc1", $format4);

              $QSBCC{$blocknum}=sprintf("%d", hex($blockcyclecounter));
              
							my $bc2 = hex($bcccomplemet);
							my $bc3 = $bc1 + $bc2;
							$filehandle->write($r, 5, "$bcccomplemet, int = $bc2", $format4);
							$filehandle1->write($r1, 5, "$bcccomplemet, int = $bc2", $format4);
							if( $bc3 == 65535 ||  $bc3 == 0)
							{
								$filehandle1->write($r1, 6, "Valid", $format4);
								$filehandle->write($r, 6, "Valid", $format4);
							}
							else
							{
								$filehandle1->write($r1, 6, "Invalid", $format3);
								$filehandle->write($r, 6, "Invalid", $format3);
							}
							
							$filehandle->write_string($r, 7, "$erasecomplete", $format4);
							$filehandle->write_string($r, 8, "$writestarted", $format4);	
							$filehandle->write_string($r, 9, "$writecomplete", $format4);	
							$filehandle->write_string($r, 10, "$erasestarted", $format4);	
							if ($erasecomplete eq '3333444455556666' && $writestarted eq '0000000000000000' && $writecomplete eq '0000000000000000' && $erasestarted eq '0000000000000000')
							{								
								$filehandle->write($r, 11, "Initial State: Data Erased", $format4);	
								$filehandle1->write($r1, 7, "Initial State", $format4);									
							}
							elsif ($erasecomplete eq '3333444455556666' && $writestarted ne '1111222277778888' && $writecomplete eq '0000000000000000' && $erasestarted eq '0000000000000000')
							{								
								$filehandle->write($r, 11, "Write Requested", $format4);	
								$filehandle1->write($r1, 7, "Write Requested", $format4);	
							}
							elsif ($erasecomplete ne '3333444455556666' && $writestarted ne '1111222277778888' && $writecomplete ne '3333444455556666' && $erasestarted eq '0000000000000000')
							{								
								$filehandle->write($r, 11, "Write Completed", $format4);	
								$filehandle1->write($r1, 7, "Write Completed", $format4);	
							}
							elsif ($erasecomplete ne '3333444455556666' && $writestarted ne '1111222277778888' && $writecomplete ne '3333444455556666' && $erasestarted ne '1111222277778888')
							{								
								$filehandle->write($r, 11, "Erase Requested", $format4);	
								$filehandle1->write($r1, 7, "Erase Requested", $format4);							}	
							else
							{								
								$filehandle->write($r, 11, "Erase in process", $format4);	
								$filehandle1->write($r1, 7, "Erase in process ", $format4);	
							}	
							$filehandle1->write($r1, 8, "$qsblockinstance{$blocknum}", $format4);	
							$filehandle1->write($r1, 9, "$blocksize{$blocknum}", $format4);							
						}		
						if( $offsetcount > 35 && $dataarray[$i] == 00 )
						{
							$quasiblockfreebytes += 1;
						}
						if ($offsetcount == $quasilimit - 1 )
						{	
							++$offsetcount;
							$filehandle1->write($r1, 10, "$offsetcount", $format4);						
							$offsetcount = -1;								
							$quasiflag = 0;
							$quasilimit = 0;						
						}
						
					}
					$address1 += 1;
				}
			}
			$linecount += 1;
			if($linecount == 2048/$bytelength)
			{
				$linecount = 0;
				$quasicount = $quasicount + 1;	
				if ($quasicount % 32 == 0)
				{
					$fa = hex($fa);
					++$fa;
					$fa = sprintf("%X", $fa);
				}
			}
		}
	}	
}

my $QSEraseCycles;
foreach my $blockno (keys(%QSBCC))
{
  if (exists $qsblockinstance{$blockno})
  {
    if ( $qsblockinstance{$blockno} == 1 )
    {
      $QSEraseCycles += $QSBCC{$blockno};
    }
    elsif ( $qsblockinstance{$blockno} > 1 )
    {
      my $bcc = $QSBCC{$blockno};
      foreach my $blocknum (@{$qsinstances{$blockno}})
      {
        if( $bcc < $QSBCC{$blocknum})
        {
          $bcc = $QSBCC{$blocknum};
        }
      }
      $QSEraseCycles += $bcc;
    }
  }  
}

$r += 2;
if( $QSEraseCycles <= 500 )
{
  $filehandle->write($r, 2, "Total erase cycles in QS area: $QSEraseCycles <= 500", $format5);
}
else
{
  $filehandle->write($r, 2, "Total erase cycles in QS area: $QSEraseCycles > 500", $format7);	
}

if( $offsetcount != -1 && $quasilimit != 0 )
{
	$quasimissedbytes{$blocknum} = $quasilimit - ($offsetcount - 1);
	$quasiblockfreebytes += $quasimissedbytes{$blocknum};
	$offsetcount = -1;
	$quasilimit = 0;						
}	
close $copyhandle; 

#Block Analysis and free spave calculation

$r1 = $r1 + 3;
$filehandle1->write($r1, 2, "Block Analysis:", $format2);			
$filehandle1->write($r1, 9, "Block Availability:", $format2);	
$filehandle1->write(++$r1, 2, "(from .xdm & .hex)", $format2);
$filehandle1->write($r1, 9, "Block present in:", $format2);
$filehandle1->write(++$r1, 9, "FEE & dump:", $format1);
my $row = $r1;	
my $c = 1;	
my $feeanddump = 0;
my $dumpnotfee = 0;
my $feenotdump = 0;
for my $key(sort {$a <=> $b} keys %matchingblocks) 
{	
	if( $key >= 0 )
	{			
		if( !( $matchingblocks{$key} =~ /Not/ ))
		{
			if( $immediate_normal{$key} eq "true")
			{
				if($qsstaticmanager{$key} eq 'true')
				{												
					$filehandle1->write(++$r1, 9, "$key(Quasi - Immediate)- $blocksize{$key} bytes", $format5);													
				}
				else
				{
					$filehandle1->write(++$r1, 9, "$key(Immediate) - $blocksize{$key} bytes", $format5);	
				}					
			}			
			else
			{
				if($qsstaticmanager{$key} eq 'true')
				{						
					$filehandle1->write(++$r1, 9, "$key(Quasi - Normal) - $blocksize{$key} bytes", $format5);						
				}
				else
				{
					$filehandle1->write(++$r1, 9, "$key(Normal) - $blocksize{$key} bytes",$format5);
				}
			}
			$feeanddump += 1;
		}
	}		
} 		
$r1 = $row;
$filehandle1->write($r1, 10, "dump but not FEE:", $format1);	
for my $key(sort {$a <=> $b} keys %matchingblocks) 
{		
	if( $key >= 0 )
	{		
		if( $matchingblocks{$key} =~ /Not/ )
		{
			$filehandle1->write(++$r1,10, "$key",$format5);	
			$dumpnotfee += 1;				
		}
	} 
}	
$r1 = $row;
$filehandle1->write($r1, 11, "FEE but not dump:", $format1);	
for my $key(sort {$a <=> $b}  @blocks ) # To check the blocks in 
{
	my $flag = 1;
	for my $value1 (sort {$a <=> $b} @missingblock ) # missing block = blocks present in fee.xdm.
	{
		if( $key == $value1 )
		{
			$flag = 0;
			last; # break the loop
		}		
	}
	if( $flag == 1 )
	{				
		if( $immediate_normal{$key} eq "true")
		{
			if($qsstaticmanager{$key} eq 'true')
			{					
				$filehandle1->write(++$r1,11, "$key(Quasi - Immediate) - $blocksize{$key} bytes", $format5);				
			}
			else
			{
				$filehandle1->write(++$r1, 11, "$key(Immediate) - $blocksize{$key} bytes", $format5);	
			}				
		}
		else
		{
			if($qsstaticmanager{$key} eq 'true')
			{					
				$filehandle1->write(++$r1, 11, "$key(Quasi - Normal) - $blocksize{$key} bytes", $format5);						
			}
			else
			{
				$filehandle1->write(++$r1, 11, "$key(Normal) - $blocksize{$key} bytes",$format5);	
			}
		}	
		$feenotdump += 1;
	}
}
#Configured blocks and cache information
$r1 = $row;
my $FEEconfiguredblocks = scalar @blocks;	
my $totalblock = $FEEconfiguredblocks + $dumpnotfee;
my $cachetable = $maxblockcount + 10;
my $cachesize = $cachetable * 20;	
$filehandle1->merge_range(++$r1,2, $r1, 3,'Sum of FEE Configured Blocks:', $format10);
$filehandle1->merge_range(++$r1,2, $r1, 3, "Sum of FEE configured blocks stored in dump:", $format10);
$filehandle1->merge_range(++$r1,2, $r1, 3, "Sum of FEE configured blocks not stored in dump:", $format10);
$filehandle1->merge_range(++$r1,2, $r1, 3, "Sum of dflash blocks not configured in FEE:", $format10);
$filehandle1->merge_range(++$r1,2, $r1, 3, "FEE configured blocks + unconfigured dflash blocks:", $format10);
$filehandle1->merge_range(++$r1,2, $r1, 3, "MaxBlockCount in .xdm", $format10);
$filehandle1->merge_range(++$r1,2, $r1, 3, "CacheTable lines (maxblock + 10)", $format10);
$filehandle1->merge_range(++$r1,2, $r1, 3, "Cachesize(Cache table lines * 20 bytes)", $format10);	
$filehandle1->merge_range(++$r1,2, $r1, 3, "Does cache hold all blocks?", $format10);
$filehandle1->merge_range(++$r1,2, $r1, 3, "Usage of cache", $format10);
$row = $r1;		
if( $cachetable >=  $totalblock )
{		
	my $percent = ( $totalblock / $cachetable ) * 100;
	$percent = sprintf "%.2f", $percent;	
	$filehandle1->write($r1, 4, "$percent % of cache is used.", $format5);
	$filehandle1->write(--$r1, 4, "Yes", $format6);		
}
else
{		
	my $diff = ( $totalblock - $cachetable);
	my $dif = sprintf "%.2f",(( $totalblock - $cachetable) / $cachetable) * 100;
	$filehandle1->write($r1, 4, "$dif % of cache is needed further.", $format5);
	$filehandle1->write(--$r1, 4, "No, $diff extra cache lines are needed.", $format5);		
}	
my $temp = $totalblock + 10;
my $temp1 = $temp * 20;	
$filehandle1->write(--$r1, 4, "$cachesize bytes", $format6);
$filehandle1->write(--$r1, 4, "$cachetable lines", $format6);
if($totalblock <= $maxblockcount)
{
	$filehandle1->write(--$r1, 4, "$maxblockcount blocks", $format6);
}
else
{
	$filehandle1->write(--$r1, 4, "$maxblockcount blocks(maxblock is lesser than the blocks in the dump)", $format5);
}

$filehandle1->write(--$r1, 4, "$totalblock", $format6);	
$filehandle1->write(--$r1, 4, "$dumpnotfee", $format6);
$filehandle1->write(--$r1, 4, "$feenotdump", $format6);
$filehandle1->write(--$r1, 4, "$feeanddump", $format6);
$filehandle1->write(--$r1, 4, "$FEEconfiguredblocks", $format6);		
# Immediate block information
$r1 = $row + 1;
$filehandle1->write(++$r1, 2, "Immediate blocks memory usage: ", $format2);
$filehandle1->write(++$r1, 2, "(from the configuration file FEE.xdm)", $format2);
$filehandle1->merge_range(++$r1,2, $r1, 3, "Configured:$threshold bytes(threshold)", $format9);		
my $immediatetotalsize = 0;
my $immediatepagesize = 0;
my $immediate_biggest = 0;
for my $value( @blocks )
{
	if( $immediate_normal{$value} eq "true")
	{			
		if( $immediate_biggest < $blocksize{$value} )
		{
			$immediate_biggest = $blocksize{$value};					
		}
		my $immediatepages = int ($blocksize{$value} / 7 ) + 2;
		if($blocksize{$value} % 7 != 0 )
		{
			$immediatepages += 1;
		}
		$immediatepagesize += $immediatepages;
		$immediatetotalsize += ( $immediatepages * 8);			
	}		
}	
my $immediate_empty = $threshold - $immediatetotalsize;
$filehandle1->write($r1, 4, "Bytes(incl. header and marker) ", $format1);
$filehandle1->write($r1, 5, "Pages (incl. header and marker)", $format1);
$filehandle1->write($r1, 6, "Feasability", $format1);	
$filehandle1->merge_range(++$r1,2, $r1, 3,"Required:", $format8);
$filehandle1->write($r1, 4, "$immediatetotalsize", $format6);
$filehandle1->write($r1, 5, "$immediatepagesize", $format6);
my $used = ( $immediatetotalsize / $threshold );
if($used > 1)
{
	$filehandle1->write($r1, 6, "Doesn't fit with threshold", $format14);
}
else
{
	$filehandle1->write($r1, 6, "Fits with threshold", $format14);
}	
my $unusedpagesize = int ( $immediate_empty / 8 );		
my $unused = ( $immediate_empty / $threshold ) * 100;
$unused = sprintf "%.2f", $unused;	
if($immediate_biggest != 0)
{
	if( $immediate_biggest % 7 == 0 )
	{
		$immediate_biggest = $immediate_biggest + 16 + (int ($immediate_biggest / 7));
	}
	else
	{
		$immediate_biggest = $immediate_biggest - ($immediate_biggest % 7) + 24 + (int ($immediate_biggest / 7));
	}
}
$filehandle1->merge_range(++$r1,2, $r1, 3, "Required(Biggest block):", $format8);	
$filehandle1->write($r1, 4, "$immediate_biggest", $format6);
my $biggestpage = int ( $immediate_biggest / 8 );
$filehandle1->write($r1, 5, "$biggestpage", $format6);
if( $immediate_biggest > $threshold )
{
	$filehandle1->write($r1, 6, "Doesn't fit with threshold", $format14);
}
else
{	
	$filehandle1->write($r1, 6, "Fits with threshold", $format14);		
}		

$r1 = $r1 + 3;	
$filehandle1->merge_range(++$r1,2, $r1, 3, "Dflash Memory Usage:", $format9);	
$r1 = $r1 + 1;	
my $temp = $sectorsize- $threshold;
$filehandle1->write(++$r1, 4, "Sector 0", $format1);
$filehandle1->write($r1, 5, "Sector 1", $format1);
$filehandle1->merge_range(++$r1, 2, $r1,  3, "Total Sector size in bytes", $format8);	
$filehandle1->write($r1, 4, "$sectorsize", $format6);
$filehandle1->write($r1, 5, "$sectorsize", $format6);
$filehandle1->merge_range(++$r1, 2, $r1,  3, "Used bytes in total sector (bytes)", $format8);	
my $used = $sectorsize - $sector0freespace; 
my $used_percent = ($used / $sectorsize) * 100;
$used_percent = sprintf "%.1f", $used_percent;
$filehandle1->write($r1, 4, "$used ($used_percent%)", $format6);
my $used = $sectorsize - $sector1freespace; 
my $used_percent = ($used / $sectorsize) * 100;
$used_percent = sprintf "%.1f", $used_percent;
$filehandle1->write($r1, 5, "$used ($used_percent%)", $format6);
$filehandle1->merge_range(++$r1, 2, $r1,  3, "Free bytes in total sector (bytes)", $format8);
my $percent_1 =  $sector0freespace / $sectorsize * 100;
$percent_1 = sprintf "%.1f", $percent_1;
$filehandle1->write($r1, 4, "$sector0freespace($percent_1 %)", $format6);
my $percent_1 =  $sector1freespace / $sectorsize * 100;
$percent_1 = sprintf "%.1f", $percent_1;
$filehandle1->write($r1, 5, "$sector1freespace($percent_1 %)", $format6);
$filehandle1->merge_range(++$r1, 2, $r1,  3, "Free bytes in sector normal area (bytes)", $format8);
my $normal_percent = ($sector0normalfreespace / $temp) *100;
$normal_percent = sprintf "%.1f", $normal_percent;
$filehandle1->write($r1, 4, "$sector0normalfreespace ($normal_percent%)", $format6);
my $normal_percent = ($sector1normalfreespace / $temp) *100;
$normal_percent = sprintf "%.1f", $normal_percent;
$filehandle1->write($r1, 5, "$sector1normalfreespace ($normal_percent%)", $format6);
$filehandle1->merge_range(++$r1, 2, $r1,  3, "Free bytes in sector immediate area (bytes)", $format8);
my $immediate_percent = ($sector0immediatefreespace / $threshold )* 100;
$immediate_percent = sprintf "%.1f", $immediate_percent;
$filehandle1->write($r1, 4, "$sector0immediatefreespace ($immediate_percent%)", $format6);	
my $immediate_percent = ($sector1immediatefreespace / $threshold )* 100;
$immediate_percent = sprintf "%.1f", $immediate_percent;
$filehandle1->write($r1, 5, "$sector1immediatefreespace ($immediate_percent%)", $format6);	
$r1 = $r1 + 2;

if($quasifeebytes > 0)
{
	$filehandle1->write(++$r1, 4, "Quasi static area", $format1);
	$filehandle1->merge_range(++$r1, 2, $r1, 3, "Available in .hex after quasi partition (bytes)", $format8);
	my $available = ($sectorsize1 *2) - $quasifirstaddress; 
	$filehandle1->write($r1, 4, "$available", $format6);
	$filehandle1->merge_range(++$r1, 2, $r1, 3, "Configured Quasi area from .xdm (bytes)", $format8);
	my $usedper = $quasifeebytes / $available* 100;
	$usedper = sprintf "%.1f", $usedper;
	$filehandle1->write($r1, 4, "$quasifeebytes($usedper%) ", $format6);
	$filehandle1->merge_range(++$r1, 2, $r1,  3, "Unconfigured or Free Quasi Area(bytes) ", $format8);
	my $unused = $available - $quasifeebytes;
	my $unusedper = $unused/$available * 100;
	$unusedper = sprintf "%.1f", $unusedper;
	$filehandle1->write($r1, 4, "$unused($unusedper%)", $format6);
	$filehandle1->merge_range(++$r1, 2, $r1,  3, "Quasi Block bytes written in configured Quasi(bytes)", $format8);
	my $used = $quasifeebytes - $quasiblockfreebytes;
	my $usedper= ($used / $quasifeebytes) * 100;
	$usedper = sprintf "%.1f", $usedper;
	$filehandle1->write($r1, 4, "$used($usedper%)", $format6);
	$filehandle1->merge_range(++$r1, 2, $r1,  3, "Quasi block bytes free in configured Quasi(bytes) ", $format8);
	my $freeper =( $quasiblockfreebytes / $quasifeebytes) * 100;
	$freeper = sprintf "%.1f", $freeper;
	$filehandle1->write($r1, 4, "$quasiblockfreebytes($freeper%)", $format6);
}
else
{
	$filehandle1->merge_range(++$r1, 2, $r1, 3, "No quasi blocks in Dflash memory", $format8);
}
$filename->close();

#End of the Program
if( defined $outputpath )
{	
	print "\n\n Fee analyzer reports are available in the given output path.\n";
	print "\n\n Output Path = $outputpath";	
}
else
{
	print "\n No output path is given by user.\n";
	print "\n Reports are available in location where this script is stored.";	
}
unlink $copy;
unlink $copy1;
unlink $copy2;
print "\n\n ****************************************";
print "\n Thank you.";
print "\n ****************************************";

##Sub routines:
#===============
# 1. Subroutine to select a device:
#------------------------------------------------------------------------------------------------------------
sub selectdevice
{	
	$title = $choice;
	if ( $choice eq "TC32x" ||  $choice eq "TC33x" ||  $choice eq "TC35x" ||  $choice eq "TC36x")
	{
		$sectorsize1 = 65536;	
		if($quasifirstaddress > 0)
		{
			my $sector0addr = hex('AF000000') + ($quasifirstaddress / 2) - 1;
			my $sector1addr = $sector0addr +1;
			$sector0addr = sprintf("%0.5X", $sector0addr);			
			$sector1addr = sprintf("%0.5X", $sector1addr);
			my $temp =hex('AF000000') + $quasifirstaddress - 1;
			my $temp = sprintf("%0.5X", $temp);
			my $quasiaddr =hex('AF000000') + $quasifirstaddress;
			$quasiaddr = sprintf("%0.5X", $quasiaddr);			
			$filehandle -> write(++$r, 5, "Sector 0: AF000000 to $sector0addr", $format4);
			$filehandle -> write(++$r, 5, "Sector 1: $sector1addr to $temp", $format4);
			$filehandle -> write(++$r, 5, "Quasi area: $quasiaddr to AF0FFFFF", $format4);
			$filehandle1 -> write(++$r1, 5, "Sector 0: AF000000 to $sector0addr", $format4);
			$filehandle1 -> write(++$r1, 5, "Sector 1: $sector1addr to $temp", $format4);
			$filehandle1 -> write(++$r1, 5, "Quasi area: $quasiaddr to AF0FFFFF", $format4);
		}
		else
		{
			$filehandle-> write(++$r, 5, "Sector 0: AF000000 to AF07FFFF", $format4);
			$filehandle -> write(++$r, 5, "Sector 1: AF080000 to AF0FFFFF", $format4);
			$filehandle1-> write(++$r1, 5, "Sector 0: AF000000 to AF07FFFF", $format4);
			$filehandle1 -> write(++$r1, 5, "Sector 1: AF080000 to AF0FFFFF", $format4);
		}	
	}
	elsif ( $choice eq "TC37x")
	{		
		$sectorsize1 = 131072;
		if($quasifirstaddress > 0)
		{
			my $sector0addr = hex('AF000000') + ($quasifirstaddress / 2) - 1;
			my $sector1addr = $sector0addr +1;
			$sector0addr = sprintf("%0.5X", $sector0addr);			
			$sector1addr = sprintf("%0.5X", $sector1addr);
			my $temp =hex('AF000000') + $quasifirstaddress - 1;
			my $temp = sprintf("%0.5X", $temp);
			my $quasiaddr =hex('AF000000') + $quasifirstaddress;
			$quasiaddr = sprintf("%0.5X", $quasiaddr);			
			$filehandle -> write(++$r, 5, "Sector 0: AF000000 to $sector0addr", $format4);
			$filehandle -> write(++$r, 5, "Sector 1: $sector1addr to $temp", $format4);
			$filehandle -> write(++$r, 5, "Quasi area: $quasiaddr to AF0FFFFF", $format4);
			$filehandle1 -> write(++$r1, 5, "Sector 0: AF000000 to $sector0addr", $format4);
			$filehandle1 -> write(++$r1, 5, "Sector 1: $sector1addr to $temp", $format4);
			$filehandle1 -> write(++$r1, 5, "Quasi area: $quasiaddr to AF0FFFFF", $format4);
		}
		else
		{
			$filehandle-> write(++$r, 5, "Sector 0: AF000000 to AF07FFFF", $format4);
			$filehandle -> write(++$r, 5, "Sector 1: AF080000 to AF0FFFFF", $format4);
			$filehandle1-> write(++$r1, 5, "Sector 0: AF000000 to AF07FFFF", $format4);
			$filehandle1 -> write(++$r1, 5, "Sector 1: AF080000 to AF0FFFFF", $format4);
		}
	}

	elsif ( $choice eq "TC38x")
	{		
		$sectorsize1 = 262144;					
		if($quasifirstaddress > 0)
		{
			my $sector0addr = hex('AF000000') + ($quasifirstaddress / 2) - 1;
			my $sector1addr = $sector0addr +1;
			$sector0addr = sprintf("%0.5X", $sector0addr);			
			$sector1addr = sprintf("%0.5X", $sector1addr);
			my $temp =hex('AF000000') + $quasifirstaddress - 1;
			my $temp = sprintf("%0.5X", $temp);
			my $quasiaddr =hex('AF000000') + $quasifirstaddress;
			$quasiaddr = sprintf("%0.5X", $quasiaddr);			
			$filehandle -> write(++$r, 5, "Sector 0: AF000000 to $sector0addr", $format4);
			$filehandle -> write(++$r, 5, "Sector 1: $sector1addr to $temp", $format4);
			$filehandle -> write(++$r, 5, "Quasi area: $quasiaddr to AF0FFFFF", $format4);
			$filehandle1 -> write(++$r1, 5, "Sector 0: AF000000 to $sector0addr", $format4);
			$filehandle1 -> write(++$r1, 5, "Sector 1: $sector1addr to $temp", $format4);
			$filehandle1 -> write(++$r1, 5, "Quasi area: $quasiaddr to AF0FFFFF", $format4);
		}
		else
		{
			$filehandle-> write(++$r, 5, "Sector 0: AF000000 to AF07FFFF", $format4);
			$filehandle -> write(++$r, 5, "Sector 1: AF080000 to AF0FFFFF", $format4);
			$filehandle1-> write(++$r1, 5, "Sector 0: AF000000 to AF07FFFF", $format4);
			$filehandle1 -> write(++$r1, 5, "Sector 1: AF080000 to AF0FFFFF", $format4);
		}
	}

	elsif ( $choice eq "TC39x")
	{				
		$sectorsize1 = 524288;	
		if($quasifirstaddress > 0)
		{
			my $sector0addr = hex('AF000000') + ($quasifirstaddress / 2) - 1;
			my $sector1addr = $sector0addr +1;
			$sector0addr = sprintf("%0.5X", $sector0addr);			
			$sector1addr = sprintf("%0.5X", $sector1addr);
			my $temp =hex('AF000000') + $quasifirstaddress - 1;
			my $temp = sprintf("%0.5X", $temp);
			my $quasiaddr =hex('AF000000') + $quasifirstaddress;
			$quasiaddr = sprintf("%0.5X", $quasiaddr);			
			$filehandle -> write(++$r, 5, "Sector 0: AF000000 to $sector0addr", $format4);
			$filehandle -> write(++$r, 5, "Sector 1: $sector1addr to $temp", $format4);
			$filehandle -> write(++$r, 5, "Quasi area: $quasiaddr to AF0FFFFF", $format4);
			$filehandle1 -> write(++$r1, 5, "Sector 0: AF000000 to $sector0addr", $format4);
			$filehandle1 -> write(++$r1, 5, "Sector 1: $sector1addr to $temp", $format4);
			$filehandle1 -> write(++$r1, 5, "Quasi area: $quasiaddr to AF0FFFFF", $format4);
		}
		else
		{
			$filehandle-> write(++$r, 5, "Sector 0: AF000000 to AF07FFFF", $format4);
			$filehandle -> write(++$r, 5, "Sector 1: AF080000 to AF0FFFFF", $format4);
			$filehandle1-> write(++$r1, 5, "Sector 0: AF000000 to AF07FFFF", $format4);
			$filehandle1 -> write(++$r1, 5, "Sector 1: AF080000 to AF0FFFFF", $format4);
		}
	}	
	elsif ($choice eq "-CustomSize")    #To know if choice is a number and it should be multiples of 8.
	{		
		my $input = $memsize;
		if ($input =~ /^\d+?$/) 
		{
			$sectorsize1 = $input / 2;
			$title = "New Version";
		}
		else
		{
			$filehandle -> write(++$r,5, "The given memory size is not a number.Please follow the instructions in user manual.", $format3);	
			$filehandle1 -> write(++$r1, 5, "The given memory size is not a number.Please follow the instructions in user manual.", $format3);						
			exit;
		}
	}
	else
	{   
		$filehandle -> write(++$r,5, "You made an invalid choice. Please follow the instructions in user manual.", $format3);	
		$filehandle1 -> write(++$r1, 5, "You made an invalid choice. Please follow the instructions in user manual.", $format3);							
		exit;		
	}
	if( $quasifirstaddress > 0)
	{
		$sectorsize = $quasifirstaddress/2;	
	}
	else
	{
		$sectorsize = $sectorsize1;	
	}
	$refcount = $sectorsize / 2048;
	$r = $r + 2;	
	$filehandle -> write($r,5, "State Block Information for $title ", $format);	
}
#-----------------------------------------------------------------------------------------------------------
# 2. Subroutine to get hex file and xdm files from user:
#------------------------------------------------------------------------------------------------------------
sub enterinputfiles
{
	if( !($input =~ /.hex/ ) )
	{
		$filehandle -> write(++$r, 5, "Input file is not a .hex file. Please follow the instructions in user manual.", $format3);	
		$filehandle1 -> write(++$r1,5, "Input file is not a .hex file. Please follow the instructions in user manual.", $format3);	
		exit;	
	}	
	if( !($input1 =~ /.xdm/ ) )
	{			
		$filehandle -> write(++$r, 5, "Input file is not a .xdm file. Please follow the instructions in user manual.", $format3);	
		$filehandle1 -> write(++$r1,5, "Input file is not a .xdm file. Please follow the instructions in user manual.", $format3);	
		exit;
	}		
	if( !($input2 =~ /.xdm/ ) )
	{			
		$filehandle -> write(++$r, 5, "Input file is not a .xdm file. Please follow the instructions in user manual.", $format3);	
		$filehandle1 -> write(++$r1,5, "Input file is not a .xdm file. Please follow the instructions in user manual.", $format3);	
		exit;
	}		

	#Copying xdm to location where FEE.exe is stored.
	$copy1 = "FEE_Copy.xdm";
	filecopy($input1,$copy1);
	$copy2 = "FLS_Copy.xdm";
	filecopy($input2,$copy2);

	my $doc = XML::LibXML->new->parse_file( "FEE_Copy.xdm" );	
	my $iter = XML::LibXML::Iterator->new( $doc );
	my $blockno = 0;
	while ( my $currentnode = $iter->nextNode() )
	{
		my $nodename = $currentnode -> nodeName;			
		# Check for the node name if it is d:lst, it represents a section of .xdm file.			
		if ( $nodename eq 'd:var' )
		{
			my @attributes = $currentnode -> getAttributes();
			my ($flag ,$flag1,$flag2, $flag3, $flag4, $flag5, $flag6, $flag7, $flag8) = 0;
			#my ($address, $blockinst, $qsblocksize
			foreach my $attribute( @attributes )
			{
				my $nodename1 = $attribute-> getName();
				my $nodevalue1 = $attribute-> getValue();								
				if( $nodename1 eq "name" && $nodevalue1 eq "FeeBlockNumber")
				{	
					$flag = 1;						
				}
				if( $flag == 1 && $nodename1 eq "value" )
				{
					push( @blocks, $nodevalue1 );
					$blockno = $nodevalue1;						
					$flag = 0;
				}					
				if( $nodename1 eq "name" && $nodevalue1 eq "FeeBlockSize")
				{	
					$flag1 = 1;					
				}
				if( $flag1 == 1 && $nodename1 eq "value" )
				{
					$blocksize{$blockno} = $nodevalue1;					
					$flag1 = 0;
				}					
				if( $nodename1 eq "name" && $nodevalue1 eq "FeeNumberOfWriteCycles")
				{	
					$flag2 = 1;					
				}
				if( $flag2 == 1 && $nodename1 eq "value" )
				{
					$blockwritecycle{$blockno} = $nodevalue1;						
					$flag2 = 0;
				}	
				if( $nodename1 eq "name" && $nodevalue1 eq "FeeImmediateData")
				{	
					$flag3 = 1;						
				}
				if( $flag3 == 1 && $nodename1 eq "value" )
				{
					$immediate_normal{$blockno} = $nodevalue1;						
					$flag3 = 0;
				}						
				if( $nodename1 eq "name" && $nodevalue1 eq "FeeThresholdValue")
				{	
					$flag4 = 1;					
				}
				if( $flag4 == 1 && $nodename1 eq "value" )
				{
					$threshold = $nodevalue1;						 
					$flag4 = 0;
				}	
				if( $nodename1 eq "name" && $nodevalue1 eq "FeeMaxBlockCount")
				{	
					$flag5 = 1;						
				}
				if( $flag5 == 1 && $nodename1 eq "value" )
				{
					$maxblockcount = $nodevalue1;						
					$flag5 = 0;
				}	
				if( $nodename1 eq "name" && $nodevalue1 eq "FeeQsBlockInstances")
				{	
					$flag6 = 1;						
				}
				if( $flag6 == 1 && $nodename1 eq "value" )
				{
					$qsblockinstance{$blockno} = $nodevalue1;						
					$flag6 = 0;
				}
				if( $nodename1 eq "name" && $nodevalue1 eq "FeeQsBlockAddress")
				{	
					$flag7 = 1;						
				}
				if( $flag7 == 1 && $nodename1 eq "value" )
				{						
					$blockaddress{$blockno} = $nodevalue1;						
					$flag7 = 0;
				}
				if( $nodename1 eq "name" && $nodevalue1 eq "FeeQuasiStaticManager")
				{	
					$flag8 = 1;						
				}
				if( $flag8 == 1 && $nodename1 eq "value" )
				{
					$qsstaticmanager{$blockno} = $nodevalue1;
					if( $qsstaticmanager{$blockno} eq 'true' )
					{
						$qsblockaddress{$blockno} = $blockaddress{$blockno};
					}						
					$flag8 = 0;
				}					
			}
		}			
	}
  
  # Get the instances of each multi instance QS block
  foreach my $blockno (keys(%qsblockinstance))
  {
    my $FirstInstance = $qsblockinstance{$blockno};
    my $FirstAddress = $blockaddress{$blockno};
    my $FirstSize = $blocksize{$blockno};
    my $QSBlock = $qsstaticmanager{$blockno};
    if (($FirstInstance > 1) && ($QSBlock eq 'true'))
    {
      foreach my $BlockNum (keys(%qsblockinstance))
      {
        if ( $qsblockinstance{$BlockNum} == 0 )
        {
          my $StartAddr = $blockaddress{$BlockNum};
          if ( ($StartAddr < ($FirstAddress + ($FirstSize * $FirstInstance))) &&
               ($StartAddr > $FirstAddress) )
          {
            push(@{$qsinstances{$blockno}}, $BlockNum);
          }
        }
      }
    }    
  }
  
  #DUMMY print
  # foreach my $blockno (keys(%qsblockinstance))
  # {
    # my $FirstInstance = $qsblockinstance{$blockno};
    # print "Block number: $blockno, Number of instances: $FirstInstance";
    # if ($FirstInstance > 1)
    # {
      # print "Instances: ";  
      # foreach my $BlockNum (sort @{$qsinstances{$blockno}})
      # {
        # print "$BlockNum,";
      # }
    # }
    # print "\n";    
  # }
  
  foreach my $key (sort {$a <=> $b} keys %qsstaticmanager)
	{
		if($qsstaticmanager{$key} eq 'true')
		{
      $quasifeebytes += $blocksize{$key};			
		}
	}	
	$quasifirstaddress = min values %qsblockaddress;		

	$doc = XML::LibXML->new->parse_file( "FLS_Copy.xdm" );	
	$iter = XML::LibXML::Iterator->new( $doc );
	while ( my $currentnode = $iter->nextNode() )
	{
		my $nodename = $currentnode -> nodeName;			
		# Check for the node name if it is d:lst, it represents a section of .xdm file.			
		if ( $nodename eq 'd:var' )
		{
			my @attributes = $currentnode -> getAttributes();
			my ($flag ,$flag1,$flag2, $flag3, $flag4) = 0;

			foreach my $attribute( @attributes )
			{
				my $nodename1 = $attribute-> getName();
				my $nodevalue1 = $attribute-> getValue();								
				if( $nodename1 eq "name" && $nodevalue1 eq "FlsTotalSize")
				{	
					$flag = 1;						
				}
				if( $flag == 1 && $nodename1 eq "value" )
				{
					$FlsTotalSize = $nodevalue1;						
					$flag = 0;
				}					
				if( $nodename1 eq "name" && $nodevalue1 eq "FlsNumberOfSectors")
				{	
					$flag1 = 1;					
				}
				if( $flag1 == 1 && $nodename1 eq "value" )
				{
					push(@FlsNumberOfSectors, $nodevalue1);
					$flag1 = 0;
				}					
				if( $nodename1 eq "name" && $nodevalue1 eq "FlsSectorSize")
				{	
					$flag2 = 1;					
				}
				if( $flag2 == 1 && $nodename1 eq "value" )
				{
					push(@FlsSectorSize, $nodevalue1);
					$flag2 = 0;
				}	
				if( $nodename1 eq "name" && $nodevalue1 eq "FlsSectorStartaddress")
				{	
					$flag3 = 1;						
				}
				if( $flag3 == 1 && $nodename1 eq "value" )
				{
					push(@FlsSectorStartaddress, $nodevalue1);
					$flag3 = 0;
				}
        if( $nodename1 eq "name" && $nodevalue1 eq "Release")
				{	
					$flag4 = 1;						
				}
				if( $flag4 == 1 && $nodename1 eq "value" )
				{
          $nodevalue1 =~ /_TRICORE_TC3(\d)/; 
					if ($choice ne "-CustomSize")
          {
            $choice = "TC3".$1."x";
          }
          $flag4 = 0;
				}	
			}
		}			
	}

  if( (scalar @FlsNumberOfSectors) == 2)
  {
    if (($FlsNumberOfSectors[DS] == 2) && 
        ($FlsNumberOfSectors[QS] == 1) && 
        ($FlsSectorStartaddress[DS] == 0) && 
        ($FlsSectorStartaddress[QS] >= ($FlsSectorSize[DS] * 2)) &&
        (($FlsSectorStartaddress[QS] + $FlsSectorSize[QS]) <= $FlsTotalSize) &&
        (($FlsSectorSize[DS] % 4096) == 0) &&
        (($FlsSectorSize[QS] % 4096) == 0) &&
        (($FlsSectorStartaddress[QS] % 4096) == 0)
       )
    {
      $ConfigType = DS_QS; # Both QS & DS configured
      if ($FlsSectorStartaddress[QS] != ($FlsSectorSize[DS] * 2))
      {
        print " Warning: There is gap between QS and NVM configured areas\n";
        print " Recommendation: Provide maximum available space for NVM area\n";
      }
      if (($FlsSectorStartaddress[QS] + $FlsSectorSize[QS]) < $DeviceSize{$choice})
      {
        print " Warning: Full dflash size may not have been used (Note: Here standard dflash0 size for device is assumed)\n";
        print " Recommendation: Provide maximum available space for NVM area\n";
      }        
    }
    else
    {
      print "Error: Incorrect sector configuration - 1\n";
    }
  
  }
  elsif ((scalar @FlsNumberOfSectors) == 1)
  {
    if (($FlsNumberOfSectors[0] == 2) &&
        (($FlsSectorSize[DS] * 2) <= $FlsTotalSize) &&
        ($FlsSectorStartaddress[DS] == 0) &&
        (($FlsSectorSize[DS] % 4096) == 0)
       )       
    {
      $ConfigType = DS; # DS only configured
      if (($FlsSectorSize[DS] * 2) < $DeviceSize{$choice})
      {
        print "Warning: Full dflash size may not have been used, (Note: Here standard dflash0 size for device is assumed)";
        print "Recommendation: Provide maximum available space for NVM area\n";
      } 
    }
    elsif (($FlsNumberOfSectors[0] == 1) &&
           (($FlsSectorSize[0] % 4096) == 0) &&
           ($FlsSectorSize[0] <= $FlsTotalSize)
          )
    {
      $ConfigType = QS; # QS only configured
      if ($FlsSectorSize[0] < $DeviceSize{$choice})
      {
        print "Info: Full dflash size may not have been used, (Note: Here standard dflash0 size for device is assumed)";
      } 
    }
    else
    {
      print "Error: Incorrect sector configuration - 2\n";
    }
  }
  else
  {
    print "Error: Incorrect sector configuration - 3\n";
  }

	$copy = "Hexfile-Copy.hex";
	filecopy($input,$copy);

  #DUMMY print
  # my $cnt=0;
  # foreach my $num (@FlsNumberOfSectors)
  # {
    # print "Sector list - $cnt, Number of sectors - $FlsNumberOfSectors[$cnt], Sector start address - $FlsSectorStartaddress[$cnt], ";
    # print "Sector size - $FlsSectorSize[$cnt]\n";
    # $cnt++;
  # }
}
#------------------------------------------------------------------------------------------------------------
# 3. Subroutine to copy file:
#------------------------------------------------------------------------------------------------------------
sub filecopy 
{
  my ($input,$copy) = @_;
  open(my $inhandle, '<', $input) or die "\nCan't open $input: $!\n";
  open(my $copyhandle, '>', $copy) or die "\nCan't open $copy: $!\n";
  print $copyhandle 
         map { my $s=$_; $s=~s/\s*#.*$//; $s } 
        (grep { !/^\s*#/ } <$inhandle>), "\n"; 
  close $inhandle;
  close $copyhandle;    
}
#------------------------------------------------------------------------------------------------------------

# 5. Forming array out of a line:
#------------------------------------------------------------------------------------------------------------
sub pushdata
{
	my $row = shift;
	my $rowlength = shift;	
	my @bytearray;
	my @dataarray;
	for( my $i = 1; $i < $rowlength - 2; $i = $i + 2   )
	{
		# To place all data bytes of a line in an array by converting into hex value.		
		my $pushvalue = substr( $row, $i, 2 ); 
		$pushvalue = hex($pushvalue);
		$pushvalue = sprintf("%0.2X", $pushvalue);	
		push( @bytearray, $pushvalue );
		if ( $i > 8)
		{
			push( @dataarray, $pushvalue );		
		}			
	}	
	return (\@bytearray, \@dataarray); #perl reference to the array.
}
#------------------------------------------------------------------------------------------------------------
# 6. Print no inforrmation in the sector:
#------------------------------------------------------------------------------------------------------------
sub printcount
{
	my $printcount = shift;
	if( $printcount == 0 )
	{
		$filehandle -> write(++$r, 5, "No information is present in this sector.", $format3);	
		$filehandle1 -> write(++$r1,5, "No information is present in this sector.", $format3);	
	}
	else
	{
		$printcount = 0;	
	}
	return $printcount;
}
# 7. Print the sector information titles:
#------------------------------------------------------------------------------------------------------------
sub printsector
{
	my $sector = shift;
	#my $totalcount = shift;
	$r = $r + 2;
	$r1 = $r1 + 2;
	$filehandle -> write($r, 2, "$sector - State Block Information", $format2);	
	$filehandle->merge_range(++$r,3, $r, 8,'Consistency', $format8);	
	$filehandle -> write(++$r, 2, "Address", $format1);	$filehandle -> write($r, 3, "Validity", $format1);	$filehandle -> write($r, 4, "Quasi Offset", $format1);	
	$filehandle -> write($r, 5, "State Counter", $format1);	$filehandle -> write($r,6, "WL Count", $format1);	$filehandle -> write($r,7, "WL0address", $format1);	$filehandle -> write($r,8, "WL1address", $format1);	$filehandle -> write($r,9, "Marker", $format1);		
	$filehandle -> write($r, 10, "CRC Value", $format1);		
}
# 8. Finding sector information:
#------------------------------------------------------------------------------------------------------------
sub findsectorinfo
{
	my ( $byteref, $dataref) = @_;	
	my @bytearray = @{$byteref};
	my @dataarray = @{$dataref};	
	if( $linecount <= ( 2048 / $bytelength )  )            
	{		
		# Converting offset to decimal				
		my $statepageaddress = 0;
		my $dataarrayindex = 0;	
		$offset = hex($bytearray[1].$bytearray[2]);	
			my $diff;	
			if( $addresscount == $offset )
			{
				$addresscount += $bytelength;
			}	
			else
			{
				 $diff = ( $offset - $bytelength - $addresscount ) / $bytelength + 1;
				my $var;
				if( $addresscount == 0 )
				{
					 $var = sprintf("%0.4X", 0);
				}
				else
				{
					 $var = sprintf("%0.4X", $addresscount - $bytelength);
				}
		
				my $offset1 = sprintf("%0.4X", $offset);
				if( $diff < 0 )
				{					
					my $increment = hex($baseaddress) - hex($baseaddress1);
					if( $flagset == 0 )
					{
						$linecount = 0;
						$totallinecount += 256;
						$count = $count + 1;					
						if( $increment == 0 )
						{	
							$baseaddress = hex($baseaddress) + 01;					
							$baseaddress = sprintf("%0.4X", $baseaddress);
							$filehandle -> write(++$r, 4, "Address lines missing: After 0x$baseaddress1$var and before 0x$baseaddress$offset1.", $format3);							
						}
						elsif( $increment > 1 )
						{
							$filehandle -> write(++$r, 4, "Address lines missing: After 0x$baseaddress1$var and before 0x$baseaddress$offset1.", $format3);								
							$count = $count + ($increment - 1)*8;
						}	
						if( $count == $refcount )
						{
							$flagset = 1;
							goto L;
						}	
					}						
					else
					{
						$flagset = 0;
					}								
					$linecount = $offset / $bytelength;	
					$totallinecount += $offset / $bytelength ;
					$baseaddress1 = hex($baseaddress1) + 01;					
					$baseaddress1 = sprintf("%0.4X", $baseaddress1);
				}
				else
				{
					$filehandle -> write(++$r, 4, "Address lines missing: After 0x$baseaddress$var and before 0x$baseaddress$offset1", $format3);	
					$linecount = $linecount + $diff;
					$totallinecount += $diff;					
				}	
				$addresscount = $offset + $bytelength;				
			}			
			if( $addresscount  == $bytelength || ( $addresscount == $offset + $bytelength && $linecount == $offset / $bytelength ) )
			{			
				my $increment = hex($baseaddress) - hex($baseaddress1);
				if( $increment >= 1  )
				{
					if( $flagset1 == 0 )
					{
						$filehandle -> write(++$r, 2, "Segment Missing: From 0x$baseaddress1 and before 0x$baseaddress.", $format3);							
						$count = $count + ($increment)*8;					
						if( $count == $refcount )
						{
							$flagset1 = 1;
							$addresscount  = $addresscount - $bytelength;
							goto L;
						}
					}
					else
					{
						$flagset1 = 0;
					}					
					$baseaddress1 = hex($baseaddress1) + $increment;					
					$baseaddress1 = sprintf("%0.4X", $baseaddress1);
				}					
			}
			if( $addresscount  == 65536 ) # increment base address if ffff address lines are counted.
			{				
				$addresscount = 0;
				$baseaddress1 = hex($baseaddress1) + 01;					
				$baseaddress1 = sprintf("%0.4X", $baseaddress1);
				$baseaddress = hex($baseaddress) + 01;					
				$baseaddress = sprintf("%0.4X", $baseaddress);
			}		
		# To check if the line has starting of statepage
		if ( (grep {$_ eq 59} @dataarray) && $statepagebytes == -1 )
		{
			++$dataarrayindex until $dataarray[$dataarrayindex] eq 59;					
			$offset = $offset + $dataarrayindex;			
			# To avoid conflict with the data block contains 59, since all data block starts with 9C, modulus should result in 0
			if( ( $dataarrayindex % 8 ) == 0 )	
			{	
				$stateflag = 1; 				
				$statepagebytes = -1;					
				#Converting offeset with index to hexa decimal and concatenate to base address to find start address of state page
				$offset = sprintf("%0.4X", $offset);							
				my $statepageaddress = $baseaddress.$offset;
				$filehandle -> write(++$r, 2, "$statepageaddress", $format4);					
				$printcount += 1;
				$validcount = 0;
				$erasedcount = 0;
				$WL0 = 0;
				$WL1 = 0;$UnerasableWLCountdec = 0;
				$stateCounter = 0;	
			}		
		}		
		if( $stateflag == 1 )
		{			 
			for( my $i = $dataarrayindex; $i < $bytelength; $i = $i + 1  )
			{
				$statepagebytes = $statepagebytes + 1;					
				# Statepage is erased if Byte 1 has value 1E and valid if it has 1D				
				if( $statepagebytes == 1 )
				{				
					if( $dataarray[$i] eq "1E" )
					{					
						$erasedcount += 1;																	
					}
					elsif ( $dataarray[$i] eq "D1" )
					{							
						$validcount += 1;																			
					}					
					$dataarrayindex = 0;	
				}				
				if( $statepagebytes == 3 )
				{							
					my $bivalue = join('', @dataarray[$i-1, $i]);				
					$quasioffset  = substr ($bivalue, 0, 3);					
					my $UnerasableWLCounthex = substr ($bivalue, 3, 1);					
					$UnerasableWLCountdec = sprintf("%d", hex($UnerasableWLCounthex));						
				}				
				# To find state counter  which is byte 4,5,6,7
				if( $statepagebytes == 7 )
				{			
					$stateCounter = join('', @dataarray[$i, $i  - 1 , $i  - 2 ,$i  - 3]);							
					$stateCounter = sprintf("%d", hex($stateCounter));										
				}				
				if( $statepagebytes == 15 )
				{			
					$WL0 = join('', @dataarray[$i, $i  - 1 , $i  - 2 ,$i  - 3]);											
				}
				if( $statepagebytes == 23 )
				{			
					$WL1 = join('', @dataarray[$i, $i  - 1 , $i  - 2 ,$i  - 3]);											
				}				
				if( $statepagebytes == 41 )
				{				
					if( $dataarray[$i] eq "1E" )
					{
						if($erasedcount == 1)
						{
							$filehandle -> write($r, 3, "Erased, Erased", $format4);	
						}
						if($erasedcount == 0)
						{
							$filehandle -> write($r, 3, "Valid, Erased", $format3);	
						}											
					}
					elsif ( $dataarray[$i] eq "D1" )
					{							
						if($validcount == 1)
						{
							$filehandle -> write($r, 3, "Valid, Valid", $format4);	
						}
						if($validcount == 0)
						{
							$filehandle -> write($r, 3, "Erased, Valid", $format3);	
						}											
					}					
				}				
				if( $statepagebytes == 43 )
				{				
					my $bivalue = join('', @dataarray[$i-1, $i]);					
					$quasioffset1  = substr ($bivalue, 0, 3);					
					my $UnerasableWLCounthex = substr ($bivalue, 3, 1);					
					my $UnerasableWLCount = sprintf("%d", hex($UnerasableWLCounthex));					
					$filehandle -> write($r, 4, "$quasioffset, $quasioffset1", $format4);	
					$filehandle -> write($r, 6, "$UnerasableWLCountdec, $UnerasableWLCount", $format4);			
				}				
				if( $statepagebytes == 47 )
				{			
					my $stateCount = join('', @dataarray[$i, $i  - 1 , $i  - 2 ,$i  - 3]);							
					$stateCount = sprintf("%d", hex($stateCount));
					$filehandle -> write($r, 5, "$stateCounter, $stateCount", $format4);										
				}				
				if( $statepagebytes == 55 )
				{			
					my $WLine0 = join('', @dataarray[$i, $i  - 1 , $i  - 2 ,$i  - 3]);							
					$filehandle -> write($r, 7, "$WL0, $WLine0", $format4);										
				}
				if( $statepagebytes == 63 )
				{			
					my $WLine1 = join('', @dataarray[$i, $i  - 1 , $i  - 2 ,$i  - 3]);							
					$filehandle -> write($r, 8, "$WL1, $WLine1", $format4);											
				}					
				if($statepagebytes == 119)
				{							
					my $crc = join('', @dataarray[$i-3, $i  - 2 , $i  - 1 ,$i]);
					if ($crc ne "00000000")
					{											
						$filehandle -> write($r, 10, $crc, $format4);											
					}
					else 
					{											
						$filehandle -> write($r, 10, "-", $format4);												
					}				
				}					
				# To check state page marker
				if( $statepagebytes == 127 )
				{						
					if( $dataarray[$i] eq 'AF' && $dataarray[$i - 1] eq 'AF' &&
						$dataarray[$i - 2] eq 'F5' && $dataarray[$i - 3] eq 'F5' &&
						$dataarray[$i - 4] eq 'AF' && $dataarray[$i - 5] eq 'AF' &&
						$dataarray[$i - 6] eq 'F5' && $dataarray[$i - 7] eq '3A' )
					{
						$filehandle -> write($r, 9, 'Valid', $format4);						
					}						
					else
					{
						$filehandle -> write($r, 9, 'Invalid', $format3);								
					}					
				}					
				# End of State page
				if( $statepagebytes == 511 )
				{
					$statepagecount += 1; 	
					$statepagebytes = -1;
					$stateflag = 0;										
				}						
			}							
		}		
	}
	$linecount = $linecount + 1;
	$totallinecount += 1;
	if( $totallinecount >= $immediaterange )
	{
		my $temp =  $threshold % $bytelength;
		if( $temp  != 0 && $lineflag == 1 )
		{				
			for( my $i = 1; $i <= $temp; $i = $i + 1  )
			{
				my $index = ( $bytelength - $i ) % 8;			
				if ($index == 0)
				{					
					if( $dataarray[$bytelength - $i] == 0 )
					{
						$immediatefreespacebytes += 8;					 
						$immediatefreespacepages += 1;
					}
				}				
			}
			$lineflag = 0;		
		}
		if( $totallinecount > $immediaterange + 1 )
		{
			for( my $i = 0; $i < $bytelength; $i = $i + 8 )
			{
				if( $dataarray[$i] == 0  )
				{				
				$immediatefreespacebytes += 8;
				$immediatefreespacepages += 1;	
				}
			}
		}
	}
	if( $linecount == ( 2048 / $bytelength  ) )
	{ 
		$linecount = 0;
		$count = $count + 1;
	}
}
# 9. Print state inoframtion titles:
#------------------------------------------------------------------------------------------------------------
sub printdatainfo
{
	for my $key(sort {$a <=> $b} keys %bcc) 
	{		
		if( $key >= 0 )
		{			
			if( $immediate_normal{$key} eq "true" )
			{
				if($qsstaticmanager{$key } eq "true")
				{
					$filehandle1 -> write(++$r1, 2, "$key (Quasi)(Immediate)", $format4);
				}
				else
				{
					$filehandle1 -> write(++$r1, 2, "$key (Immediate)", $format4);
				}
			}
			elsif( $immediate_normal{$key} eq "false" )
			{
				
				if($qsstaticmanager{$key } eq "true")
				{
					$filehandle1 -> write(++$r1, 2, "$key (Quasi)(Normal)", $format4);
				}
				else
				{
					$filehandle1 -> write(++$r1, 2, "$key (Normal)", $format4);
				}
				
			}
			else
			{
				$filehandle1 -> write(++$r1, 2, "$key", $format4);	
			}
					
			$filehandle1 -> write($r1, 3, "$address{$key}", $format4);
			$filehandle1 -> write($r1, 4, "$bcc{$key}", $format4);				
			$filehandle1 -> write($r1, 5, "$pagevalid{$key}", $format4);			
			if( $consistent{$key} )
			{
				$filehandle1 -> write($r1, 6, "$consistent{$key}", $format4);	
			}
			else
			{
				$filehandle1 -> write($r1, 6, "0", $format4);
			}
			if($inconsistent{$key})
			{
				$filehandle1 -> write($r1, 7, "$inconsistent{$key}", $format4);	
			}
			else
			{
				$filehandle1 -> write($r1, 7, "0", $format4);	
			}
			if($markermissing{$key})
			{
				$filehandle1 -> write($r1, 8, "$markermissing{$key}", $format4);			
			}
			else
			{
				$filehandle1 -> write($r1, 8, "0", $format4);
			}
			if( $consistent{$key} )
			{
				if( $consistent{$key} == $differ{$key} )
				{
					my $bc = 0;
					my $pcc = 0;
					$filehandle1 -> write($r1, 9, "Consistent BCC, $firstbcc{$key} .. $lastbcc{$key}", $format4);						
					my $l = 20 + length($firstbcc{$key}) + length($lastbcc{$key});				
					$bc = int ( $blocksize{$key} / 7 );					
					if( $blocksize{$key} % 7 == 0 )
					{
						$bc = $blocksize{$key} / 7 + 2; 
					}
					else
					{
						$bc = int ( $blocksize{$key} / 7 ) + 3; 
					}						
					$pcc = $pc{$key} + 1;					
					if ( $bc == $pcc )
					{							
						$filehandle1 -> write($r1, 10, "Equal", $format4);
						
					}
					else
					{										
						if( grep {$_ eq $key} @blocks )
						{								
							$filehandle1 -> write($r1, 10, "Not Equal", $format3);
						}
						else
						{								
							$filehandle1 -> write($r1, 10, ".........", $format4);
						}
					}			
										
					if( $blockwritecycle{$key} > 0 )
					{						
						if ( $firstbcc{$key} <= $blockwritecycle{$key} && $lastbcc{$key} <= $blockwritecycle{$key})
						{
							$filehandle1 -> write($r1, 11, "BCC < FEE Write Cycle.", $format4);							
						}
						else
						{
							$filehandle1 -> write($r1, 11, "BCC > FEE Write Cycle.", $format4);
						}
					}
					else					
					{					
						$filehandle1 -> write($r1, 11, "FEE Write Cycle = 0.", $format4);										
					}				
				}
				else
				{						
					$filehandle1 -> write($r1, 9, "BCC Inconsistent $firstbcc{$key} .. $lastbcc{$key}", $format3);	
				}
			}
			else
			{
				$filehandle1 -> write($r1, 9, "No Consistent data block", $format3);				
			}
		}	
	}	
	foreach my $key1 (keys %consistent)
	{
	  foreach my $val (@blocks)
	  {
		if ($key1 eq $val) 
		{
		  $matchingblocks{$key1} =  "Present in FEE.XDM";
		  push(@missingblock, $key1);
		  last;
		}
		else 
		{
		  $matchingblocks{$key1} =  "Not Present in FEE.XDM";
		}
	  }
	}
	
	foreach my $key1 (keys %inconsistent)
	{
	  foreach my $val (@blocks)
	  {
		if ($key1 eq $val) 
		{
		  if(!$consistent{$key1} )
		  {
			$matchingblocks{$key1} =  "Present in FEE.xdm ";
			push(@missingblock, $key1);
		  }
		 
		  last;
		}
		else 
		{
		  if(!$consistent{$key1})
		  {
			$matchingblocks{$key1} =  "Not Present in FEE.xdm ";
		  }
		}
	  }
	}
		
	undef %address;
	undef %pc ;
	undef %bcc ;
	undef %pagevalid;
	undef %consistent ;
	undef %inconsistent ;		
	undef %markermissing ;	
	undef %differ ;
	undef %firstbcc ;
	undef %lastbcc ;
}


# 10. Print data informAation titles:
#------------------------------------------------------------------------------------------------------------
sub printdatatitle
{
	my $sector = shift;
	#my $totalcount = shift;	
	
	$r = $r + 2;
	$r1 = $r1 + 2;
	$filehandle1 -> write($r1, 2, "$sector - Datablocks (Double Sector Algorithm)", $format2);	
	$filehandle1 -> write(++$r1, 2, "Block", $format1);	
	$filehandle1 -> write($r1, 3, "Last Address", $format1);
	$filehandle1 -> write($r1, 4, "Last BCC", $format1);		
	$filehandle1 -> write($r1, 5, "Page Valid", $format1);	
	$filehandle1->write($r1, 6, "Consistent", $format1);	
	$filehandle1->write($r1, 7, "Inconsistent", $format1);	
	$filehandle1->write($r1, 8, "Marker Missing", $format1);	
	$filehandle1->write($r1, 9, "BCC Consistency", $format1);
	$filehandle1->write($r1, 10, "Block size in .xdm & Block Bytes written in .hex", $format1);		
	$filehandle1->write($r1, 11, "FEE Write cycle and BCC", $format1);				
		
	$filehandle -> write($r, 2, "$sector - Data Block Information:", $format2);	
	$filehandle -> write(++$r, 2, "Block", $format1);	
	$filehandle -> write($r, 3, "Data Block ID", $format1);	
	$filehandle -> write($r, 4, "Address", $format1);	
	$filehandle -> write($r, 5, "Data Page Validity", $format1);	
	$filehandle -> write($r, 6, "BCC", $format1);	
	$filehandle -> write($r, 7, "PC PageInfo", $format1);
	$filehandle -> write($r, 8, "Total Pages", $format1);	
	$filehandle -> write($r, 9, " xdm Pages", $format1);	
	$filehandle -> write($r, 10, " Written Pages", $format1);
	$filehandle -> write($r, 11, "Consistency with .xdm", $format1);
	$filehandle -> write($r, 12, "Consistency with dump", $format1);
}

# 11. Find data information :
#------------------------------------------------------------------------------------------------------------
sub finddatainfo
{
	my ( $byteref, $dataref) = @_;	
	my @bytearray = @{$byteref};
	my @dataarray = @{$dataref};
	$offset = hex($bytearray[1].$bytearray[2]);		
	# To equate the section to 2048 lines if some lines are missing.
		my $diff;	
		if( $addresscount == $offset )
		{
			$addresscount += $bytelength;
		}	
		else
		{
			 $diff = ( $offset - $bytelength - $addresscount ) / $bytelength + 1; # To find missing lines
			my $var;
			if( $addresscount == 0 )
			{
				 $var = sprintf("%0.4X", 0);
			}
			else
			{
				 $var = sprintf("%0.4X", $addresscount - $bytelength);
			}	
			my $offset1 = sprintf("%0.4X", $offset);
			if( $diff < 0 ) 
			{				
				my $increment = hex($baseaddress) - hex($baseaddress1);				
				if( $flagset == 0 )
				{
					$linecount = 0;
					$count = $count + 1;					
					if( $increment == 0 )
					{
						$baseaddress = hex($baseaddress) + 01;					
						$baseaddress = sprintf("%0.4X", $baseaddress);						
					}
					elsif( $increment > 1 )
					{						
						$count = $count + ($increment - 1)*8;
					}	
					if( $count == $refcount )
					{
						$flagset = 1;
						goto L11;
					}	
				}						
				else
				{
					$flagset = 0;
				}								
				$linecount = $offset / $bytelength;					
				$baseaddress1 = hex($baseaddress1) + 01;					
				$baseaddress1 = sprintf("%0.4X", $baseaddress1);				
			}
			else
			{				
				$linecount = $linecount + $diff;				
			}	
			$addresscount = $offset + $bytelength;			
		}		
		if( $addresscount  == $bytelength || ( $addresscount == $offset + $bytelength && $linecount == $offset / $bytelength ) )
		{			
			my $increment = hex($baseaddress) - hex($baseaddress1);
			if( $increment >= 1  )
			{
				if( $flagset1 == 0 )
				{
					$count = $count + ($increment)*8;					
					if( $count == $refcount )
					{
						$flagset1 = 1;
						$addresscount  = $addresscount - $bytelength;
						goto L11;
					}
				}
				else
				{
					$flagset1 = 0;
				}				
				
				$baseaddress1 = hex($baseaddress1) + $increment;					
				$baseaddress1 = sprintf("%0.4X", $baseaddress1);
			}				
		}
		if( $addresscount  == 65536 )
		{		
			$addresscount = 0;
			$baseaddress1 = hex($baseaddress1) + 01;					
			$baseaddress1 = sprintf("%0.4X", $baseaddress1);
			$baseaddress = hex($baseaddress) + 01;					
			$baseaddress = sprintf("%0.4X", $baseaddress);
		}	
	if( $linecount <= ( 2048 / $bytelength)  )            
	{					
		# Converting offset to decimal				
		my $statepageaddress = 0;			
		my $i= 0;		
		# To check if the line has starting of Data Block
		for( $i = 0; $i < $bytelength; $i = $i + 8 )
		{				
			#To check if the Marker is changed.			
			my $pushvalue = substr( $dataarray[$i], 0, 1 );
			my $pushvalue1 = substr( $dataarray[$i], 1, 1 );		
			if ( $pushvalue eq "A" || $pushvalue1 eq "3")
			{          
				if( $pagecount >= 0  )
				{				
					if( $bin == 0) 
					{
						if( $blocks ne $pagecount1 && $set == 1 && $blocks ne '-' )
						{
							$filehandle -> write($r,10, "$pagecount1", $format3);
							$filehandle -> write($r,11, "Inconsistent with .xdm", $format3);

							$set = 0;
						}
						else
						{
							if( $blocks eq '-' )
							{
								$filehandle -> write($r,10, "$pagecount1", $format4);
								$filehandle -> write($r,11, "No configuration in .xdm", $format4);								
							}
							else
							{
								$filehandle -> write($r,10, "$pagecount1", $format4);
								$filehandle -> write($r,11, "Consistent with .xdm", $format4);
							}								
						}						
						$filehandle -> write($r,12, "Inconsistent, PC:0, pages exists.", $format4);																
						my $value = 0;
						if ( exists $inconsistent{$blocknumber} )
						{				
						   $value = $inconsistent{$blocknumber} + 1;
						}	
						else
						{
							$value = 1;
						}
						$inconsistent{$blocknumber} = $value;		
					}
					else 
					{							
						if( $flag == 0 )
						{
							if( $blocks ne $pagecount1 && $set == 1 && $blocks ne '-' )
							{
								$filehandle -> write($r,10, "$pagecount1", $format3);
								$filehandle -> write($r,11, "Inconsistent with .xdm", $format3);
								$set = 0;
							}
							else
							{
								if( $blocks eq '-' )
								{
									$filehandle -> write($r,10, "$pagecount1", $format4);
									$filehandle -> write($r,11, "No configuration in .xdm", $format4);								
								}
								else
								{
									$filehandle -> write($r,10, "$pagecount1", $format4);
									$filehandle -> write($r,11, "Consistent with .xdm", $format4);
								}								
							}
							$filehandle -> write($r,12, "Inconsistent ( Marker Missing )", $format7);							
							my $value = 0;
							if ( exists $markermissing{$blocknumber} )
							{							
							   $value = $markermissing{$blocknumber} + 1;
							}	
							else
							{
								$value = 1;
							}
							$markermissing{$blocknumber} = $value;	
							if ( exists $inconsistent{$blocknumber} )
							{							
							   $value = $inconsistent{$blocknumber} + 1;
							}	
							else
							{
								$value = 1;
							}
							$inconsistent{$blocknumber} = $value;									
						}
					}
					$stateflag = 0;
					$datapagecount = 0;	
					$pagecount = -1;
					$pagecount1 = 0;
					$bin = 0;
					$flag = 0;
				}					
				$offset = hex($bytearray[1].$bytearray[2]);					
				$offset = $offset + $i;
				$offset = sprintf("%0.4X", $offset);			
				my $statepageaddress = $baseaddress.$offset;				
				$blocknumber = hex($dataarray[$i + 2].$dataarray[$i + 1]);
				$blockcyclecounter = hex($dataarray[$i + 5].$dataarray[$i + 4].$dataarray[$i + 3]);				
				$address{$blocknumber} = $statepageaddress;
				if( $bcc{$blocknumber} )				{
					$diff =  $blockcyclecounter - $bcc{$blocknumber};
				}				
				$bcc{$blocknumber} = $blockcyclecounter;				
				#To check if the data page marker changes from A3 to some other value
				if( $pushvalue eq "A" && $pushvalue1 == 3 )
				{
					$filehandle -> write(++$r,2, "$blocknumber", $format4);
					$filehandle -> write($r,3, "A3", $format4);					
				}
				else
				{
					$filehandle -> write(++$r,2, "$blocknumber", $format4);					
					$filehandle -> write($r,3, "A3 to $pushvalue$pushvalue1", $format3);						
				}				
				$filehandle -> write($r,4, "$statepageaddress", $format4);
				$printcount += 1;				
				#To find the validity of data page Erase or Valid
				 $validblock = $dataarray[$i + 7].$dataarray[$i + 6];						 
				 $bin = sprintf("%.16b", hex($validblock)); 
				 $bin = reverse ($bin);
				 my $validity = chop($bin);
				 $bin = reverse ($bin);				 
				 # To convert from bin to dec
				 $bin = bin2dec($bin);
				 $pc{$blocknumber} = $bin;
				 sub bin2dec
				 {
					return unpack("N", pack("B32", substr("0" x 32 . shift, -32)));
				 }				 
				 #Byte 1 last bit represents the validity of the page
				 if($validity)
				 {							
					$filehandle -> write($r,5, "Valid", $format4);					
					$pagevalid{$blocknumber} = "Valid";						
				 }
				 else
				 {							
					$filehandle -> write($r,5, "Invalid", $format3);
					$pagevalid{$blocknumber} = "Invalid";
				 }				
				$filehandle -> write($r,6, "$blockcyclecounter", $format4);			
				my $total = $bin + 1; # bin - pages in header, total = pages + one header.
				$filehandle -> write($r,7, "$bin", $format4);
				$filehandle -> write($r,8, "$total", $format4);
			    my $bc = 0;									
				if ( $blocksize{$blocknumber} )
				{
					if( $blocksize{$blocknumber} % 7 == 0 )
					{
						$bc = $blocksize{$blocknumber} / 7 + 2; 
					}
					else
					{
						$bc = int ( $blocksize{$blocknumber} / 7 ) + 3; 
					}
				}
				else
				{
					$bc = "-";
				}
				$filehandle -> write($r,9, "$bc", $format4);													
				$stateflag = 1;	
				$blocks = $bc;
				$set = 1;				
			} 			
			if( $stateflag == 1 )
			{					
				$pagecount = $pagecount + 1;	#increments to 0 from -1 if a data block begins and increments further			
				if( $dataarray[$i] eq "9C" )
				{
					$datapagecount = $datapagecount + 1;
				}				
				my $bn = hex( $dataarray[$i + 5].$dataarray[$i + 4] ); # block number
				my $vb = $dataarray[$i + 7].$dataarray[$i + 6]; #valid block				
				my $pushvalue = substr( $dataarray[$i], 0, 1 );
				my $pushvalue1 = substr( $dataarray[$i], 1, 1 );				
				if( ($pushvalue ne 0 || $pushvalue1 ne 0) && ( $dataarray[$i] ne "59" ) && $dataarray[$i] ne "3A")
				{
					$pagecount1 = $pagecount1 + 1;
				}
				if( $pagecount == $bin && ( $pushvalue eq 6 || $pushvalue1 eq 5 ) )
				{										
					if( $bn == $blocknumber && $vb eq $validblock  )
					{					
						if( $datapagecount == ($bin - 1) && $dataarray[$i] eq "65" && $dataarray[$i + 1] eq "AF" && $dataarray[$i+2] eq "F5" && $dataarray[$i+3] eq "F5" )						
						{							
							if( $blocks ne $pagecount1 && $set == 1 && $blocks ne '-' )
							{								
								if($bin == 1)
								{
									$filehandle -> write($r,11, "Invalidated block(So, differs with .xdm)", $format13);
									$filehandle -> write($r,10, "$pagecount1", $format4);
								}
								else
								{
									$filehandle -> write($r,10, "$pagecount1", $format3);
									$filehandle -> write($r,11, "Inconsistent with .xdm", $format3);
								}
								$set = 0;
							}
							else
							{
								if( $blocks eq '-' )
								{									
									$filehandle -> write($r,10, "$pagecount1", $format4);
									$filehandle -> write($r,11, "No configuration in .xdm ", $format4);								
								}
								else
								{
									$filehandle -> write($r,10, "$pagecount1", $format4);
									$filehandle -> write($r,11, "Consistent with .xdm", $format4);
								}			
							}
							$filehandle -> write($r,12, "Consistent", $format4);
							my $value = 0;
							my $value1 = 0;
							if ( exists $consistent{$blocknumber} )
							{							
							   $value = $consistent{$blocknumber} + 1;
							   my $value3 = $blockcyclecounter - $lastbcc{$blocknumber};
							   if( $diff == 1 ||  $diff == 0 && $value3 == 1)
							   {
								 
								 $value1 = $differ{$blocknumber} + 1;
							   }
							}	
							else
							{
								$value = 1;
								$value1 = 1;
								$firstbcc{$blocknumber} = $blockcyclecounter;
							}
							$consistent{$blocknumber} = $value;	
							$differ{$blocknumber} = $value1;
							$lastbcc{$blocknumber} = $blockcyclecounter;												
						}						 
						else
						{							
							if( $blocks ne $pagecount1 && $set == 1 && $blocks ne '-')
							{
								$filehandle -> write($r,10, "$pagecount1", $format3);
								$filehandle -> write($r,11, "Inconsistent with .xdm", $format3);
								$set = 0;
							}
							else
							{
								if( $blocks eq '-' )
								{
									$filehandle -> write($r,10, "$pagecount1", $format4);
									$filehandle -> write($r,11, "No configuration in .xdm ", $format4);								
								}
								else
								{
									$filehandle -> write($r,10, "$pagecount1", $format4);
									$filehandle -> write($r,11, "Consistent with .xdm", $format4);
								}			
							}
							if ($dataarray[$i] eq "65" && $dataarray[$i + 1] eq "AF" && $dataarray[$i+2] eq "F5" && $dataarray[$i+3] eq "F5")
							{
								if($datapagecount == ($bin - 1))
								{
									$filehandle -> write($r,12, "Inconsistent ( Incorrect written data pages)", $format7);
								}
								else
								{
									$filehandle -> write($r,12, "Inconsistent ( Incorrect pageID in data pages)", $format7);
								}
							}
							else
							{
									$filehandle -> write($r,12, "Inconsistent ( Change in Marker )", $format7);
							}							
							my $value = 0;
							if ( exists $inconsistent{$blocknumber} )
							{							
							   $value = $inconsistent{$blocknumber} + 1;
							}	
							else
							{
								$value = 1;
							}
							$inconsistent{$blocknumber} = $value;								
						} 							
					}
					else
					{					
						if( $blocks ne $pagecount1 && $set == 1 && $blocks ne '-')
						{
							$filehandle -> write($r,10, "$pagecount1", $format3);
							$filehandle -> write($r,11, "Inconsistent with .xdm", $format3);
							$set = 0;
						}
						else
						{
							if( $blocks eq '-' )
							{
								$filehandle -> write($r,10, "$pagecount1", $format4);
								$filehandle -> write($r,11, "No configuration in .xdm ", $format4);								
							}
							else
							{
								$filehandle -> write($r,10, "$pagecount1", $format4);
								$filehandle -> write($r,11, "Consistent with .xdm", $format4);
							}			
						}
						$filehandle -> write($r,10, "$pagecount1", $format4);
						$filehandle -> write($r,11, "Consistent with .xdm", $format4);
						$filehandle -> write($r,12, "Inconsistent ( change in block number value or page count value in marker)", $format7);							
						my $value = 0;
						if ( exists $inconsistent{$blocknumber} )
						{					
						   $value = $inconsistent{$blocknumber} + 1;
						}	
						else
						{
							$value = 1;
						}
						$inconsistent{$blocknumber} = $value;						
					} 
					$stateflag = 0;
					$datapagecount = 0;	
					$pagecount = -1;
					$pagecount1 = 0;
					$bin = 0;			
				}
				elsif ( $pagecount - $bin == 1 && $bin != 0  ) 
				{						
					if( $blocks ne $pagecount1 && $set == 1 && $blocks ne '-' )
					{
						$filehandle -> write($r,10, "$pagecount1", $format3);
						$filehandle -> write($r,11, "Inconsistent with .xdm", $format3);
						$set = 0;
					}
					else
					{
						$filehandle -> write($r,10, "$pagecount1", $format4);
						if( $blocks eq '-' )
						{
							$filehandle -> write($r,10, "$pagecount1", $format4);
							$filehandle -> write($r,11, "No configuration in .xdm ", $format4);								
						}
						else
						{
							$filehandle -> write($r,10, "$pagecount1", $format4);
							$filehandle -> write($r,11, "Consistent with .xdm", $format4);
						}		
					}					
					$filehandle -> write($r,12, "Inconsistent ( Marker Missing )", $format7);					
					$flag = 1;	
					my $value = 0;
					if ( exists $markermissing{$blocknumber} )
					{					
					   $value = $markermissing{$blocknumber} + 1;
					}	
					else
					{
						$value = 1;
					}
					$markermissing{$blocknumber} = $value;	
					if ( exists $inconsistent{$blocknumber} )
					{					
					   $value = $inconsistent{$blocknumber} + 1;
					}	
					else
					{
						$value = 1;
					}
					$inconsistent{$blocknumber} = $value;					
				}			
			}					
		}			
		# Incrementing address count till it iterates through full sector length
		$linecount = $linecount + 1;
		if( $linecount == (  2048 / $bytelength) )
		{
			$linecount = 0;
			$count = $count + 1;					
		}				
	}
}	

# 12. Check if there is skipped WL:
#------------------------------------------------------------------------------------------------------------
sub CheckWLIssue
{
  my $TempAddr;
  if($EmptyWL{$WLAddress} == 0) # Empty WL found
  {
    $CurEmpty = 1;
    if(($WLAddress <= $CurThreshold) && 
       (($WLAddress + 512) > $CurThreshold )
      )
    {
      $PrevEmpty = 0;
      $LongEmpty = 0;
    }
  }
  else # Non-empty WL found
  {
    $CurEmpty = 0;
    if($PrevEmpty == 1)
    {
      if($LongEmpty == 1)
      {
        if(($WLAddress <= $CurThreshold) && 
           (($WLAddress + 512) > $CurThreshold )
          )
        {
          # Threshold crossed and immediate blocks written.
          $TempAddr = 0xAF000000 + $FlsSectorStartaddress[DS] + $PrevAddr;
          $TempAddr = sprintf("%0.4X",$TempAddr);
          push(@WLIssues,"Multiple wordlines skipped at the following address, potentially due to data block could not be fit before threshold: $TempAddr");
          $PrevEmpty = 0;
          $LongEmpty = 0;
        }
        else
        {
          $TempAddr = 0xAF000000 + $FlsSectorStartaddress[DS] + $WLAddress;
          $TempAddr = sprintf("%0.4X",$TempAddr);
          push(@WLIssues,"More than 1 empty wordline and then valid data found at following address, this is unexpected!!: $TempAddr");
        }
      }
      elsif(($WLAddress <= $CurThreshold) && 
            (($WLAddress + 512) > $CurThreshold )
           )
      {
        # Threshold crossed and immediate blocks written.
        $TempAddr = 0xAF000000 + $FlsSectorStartaddress[DS] + $PrevAddr;
        $TempAddr = sprintf("%0.4X",$TempAddr);
        push(@WLIssues,"Wordline skipped at the following address, potentially due to data block could not be fit before threshold: $TempAddr");
        $PrevEmpty = 0;
        $LongEmpty = 0;
      }
      else
      {
        $TempAddr = 0xAF000000 + $FlsSectorStartaddress[DS] + $PrevAddr;
        $TempAddr = sprintf("%0.4X",$TempAddr);
        push(@WLIssues,"Wordline skipped at the following address, potentially due to wordline issue during write: $TempAddr");
      }
    }
    $LongEmpty = 0;
  }
  if( $CurEmpty == 1 && $PrevEmpty == 1)
  {
    $LongEmpty = 1;
  }     
  $PrevEmpty = $CurEmpty;
  $PrevAddr = $WLAddress;
}